# Soundboard 1.0.0 — Premium Blue Edition

Projeto Android Kotlin do Soundboard (`com.soundboard.app`). Esta entrega é uma atualização incremental sobre o projeto 0.9 enviado pelo usuário.

## Novidade 1.0.0 incluída nesta revisão

- A bolinha flutuante agora reage ao estado real de reprodução: quando um ou mais áudios estão tocando, ela muda para o símbolo musical e executa uma pulsação elétrica azul, com escala, brilho e contorno animados.
- Ao pausar, concluir ou parar todos os áudios, a bolinha retorna ao estado normal.
- A animação é executada localmente no overlay e não altera o mecanismo de reprodução nem os efeitos de áudio existentes.
- Atualização de `versionCode` para 10 e `versionName` para `1.0.0`.

## Recursos preservados

- Biblioteca de áudios, categorias, pesquisa e favoritos.
- Reprodução por `MediaPlayer`, equalizador, reforço de graves, loudness e limitador de volume.
- Janela flutuante sobre outros aplicativos.
- Mascote e vídeo de introdução `soundboard_intro.mp4`.
- Interface e configurações já existentes.

## Compilar

```bash
gradle --no-daemon clean assembleDebug
```

APK Debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Observação

Esta entrega implementa o efeito visual da bolinha e a identificação 1.0.0. Perfis múltiplos, fila de reprodução, temporizador, backup exportável e personalização avançada de efeitos ainda não foram implementados nesta revisão. O áudio permanece com o mecanismo original; o Android não garante que o som reproduzido pelo aplicativo seja enviado ao microfone de todo aplicativo de chamada.
