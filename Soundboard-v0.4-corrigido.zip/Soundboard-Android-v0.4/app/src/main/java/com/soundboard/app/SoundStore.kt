package com.soundboard.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Persistent, dynamically-sized audio library. */
object SoundStore {
    private const val PREFS = "soundboard_v03"
    private const val KEY_SOUNDS = "sounds"
    private const val KEY_VOLUME = "volume"
    private const val KEY_ACCENT = "accent"
    private const val KEY_KEEP_BUBBLE = "keep_bubble"

    data class Sound(
        val id: String,
        val uri: String,
        val name: String,
        val category: String = "Geral",
        val favorite: Boolean = false
    )

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun all(c: Context): MutableList<Sound> {
        val raw = prefs(c).getString(KEY_SOUNDS, "[]") ?: "[]"
        val out = mutableListOf<Sound>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Sound(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.optString("uri"), o.optString("name", "Áudio"),
                    o.optString("category", "Geral"), o.optBoolean("favorite", false)
                ))
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized private fun save(c: Context, sounds: List<Sound>) {
        val arr = JSONArray()
        sounds.forEach { s ->
            arr.put(JSONObject().put("id", s.id).put("uri", s.uri)
                .put("name", s.name).put("category", s.category).put("favorite", s.favorite))
        }
        prefs(c).edit().putString(KEY_SOUNDS, arr.toString()).apply()
    }

    fun add(c: Context, uri: Uri, name: String): Sound {
        val item = Sound(UUID.randomUUID().toString(), uri.toString(), name.ifBlank { "Novo áudio" })
        val list = all(c); list.add(item); save(c, list); return item
    }
    fun update(c: Context, item: Sound) {
        val list = all(c); val i = list.indexOfFirst { it.id == item.id }
        if (i >= 0) { list[i] = item; save(c, list) }
    }
    fun delete(c: Context, id: String) { save(c, all(c).filterNot { it.id == id }) }
    fun get(c: Context, id: String): Sound? = all(c).firstOrNull { it.id == id }
    fun categories(c: Context): List<String> =
        listOf("Geral", "Efeitos", "Memes", "Música", "Vozes", "Outros") +
            all(c).map { it.category }.filter { it.isNotBlank() }.distinct()

    fun volume(c: Context) = prefs(c).getInt(KEY_VOLUME, 75)
    fun setVolume(c: Context, value: Int) { prefs(c).edit().putInt(KEY_VOLUME, value.coerceIn(0,100)).apply() }
    fun accent(c: Context) = prefs(c).getString(KEY_ACCENT, "lime") ?: "lime"
    fun setAccent(c: Context, value: String) { prefs(c).edit().putString(KEY_ACCENT, value).apply() }
    fun keepBubble(c: Context) = prefs(c).getBoolean(KEY_KEEP_BUBBLE, true)
    fun setKeepBubble(c: Context, value: Boolean) { prefs(c).edit().putBoolean(KEY_KEEP_BUBBLE, value).apply() }
}
