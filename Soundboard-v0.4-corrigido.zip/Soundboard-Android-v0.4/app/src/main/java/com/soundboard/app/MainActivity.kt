package com.soundboard.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private var query = ""
    private var favoritesOnly = false
    private var categoryFilter = "Todas"
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private lateinit var search: EditText
    private lateinit var quickFavorites: LinearLayout
    private lateinit var libraryTitle: LinearLayout
    private lateinit var favoritesCount: TextView
    private lateinit var categoriesCount: TextView
    private val lime: Int
        get() = when (SoundStore.accent(this)) {
            "blue" -> 0xFF48A8FF.toInt()
            "purple" -> 0xFFC18BFF.toInt()
            else -> 0xFFB6FF00.toInt()
        }
    private val bg = 0xFF090B09.toInt()
    private val card = 0xFF151915.toInt()
    private val muted = 0xFF9AA398.toInt()

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris?.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            SoundStore.add(this, uri, displayName(uri) ?: "Áudio importado")
        }
        if (!uris.isNullOrEmpty()) {
            refreshLibrary()
            Toast.makeText(this, "${uris.size} arquivo(s) importado(s)", Toast.LENGTH_SHORT).show()
            refreshFloating()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.decorView.systemUiVisibility = 0
        buildHome()
    }
    override fun onResume() { super.onResume(); if (::list.isInitialized) refreshLibrary() }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "SOUNDBOARD"; textSize = 25f; setTextColor(lime); setTypeface(null, 1)
        }
        val version = TextView(this).apply {
            text = "  0.4"; textSize = 12f; setTextColor(muted)
        }
        top.addView(brand); top.addView(version)
        val settingsIcon = textAction("⚙") { showSettings() }
        top.addView(settingsIcon)
        content.addView(top)
        content.addView(label("SUA CENTRAL DE ÁUDIO", 10f, muted).apply {
            setPadding(0, dp(3), 0, dp(17))
        })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(0xFF151D14.toInt(), dp(16))
        }
        hero.addView(label("CONTROLE SEUS SONS", 17f, -1).apply { setTypeface(null, 1) })
        hero.addView(label("Sua biblioteca. Seus atalhos. Tudo em um só lugar.", 11f, muted).apply {
            setPadding(0, dp(4), 0, dp(13))
        })
        val heroActions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        heroActions.addView(button("+ IMPORTAR ÁUDIOS") { pickAudio.launch(arrayOf("audio/*")) },
            LinearLayout.LayoutParams(0, dp(46), 1f))
        val floating = button("JANELA S") { activateFloating() }
        val floatingLp = LinearLayout.LayoutParams(dp(112), dp(46)); floatingLp.leftMargin = dp(8)
        heroActions.addView(floating, floatingLp)
        hero.addView(heroActions)
        content.addView(hero)

        val metrics = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(17)) }
        val total = metricCard("ÁUDIOS", SoundStore.all(this).size.toString())
        count = total.second
        metrics.addView(total.first, LinearLayout.LayoutParams(0, dp(76), 1f))
        val favCount = SoundStore.all(this).count { it.favorite }
        val favoriteMetric = metricCard("FAVORITOS", favCount.toString())
        favoritesCount = favoriteMetric.second
        metrics.addView(favoriteMetric.first, LinearLayout.LayoutParams(0, dp(76), 1f).apply { leftMargin = dp(8) })
        val categoryMetric = metricCard("CATEGORIAS", SoundStore.categories(this).distinct().size.toString())
        categoriesCount = categoryMetric.second
        metrics.addView(categoryMetric.first, LinearLayout.LayoutParams(0, dp(76), 1f).apply { leftMargin = dp(8) })
        content.addView(metrics)

        content.addView(sectionTitle("ACESSO RÁPIDO", "Atalhos para suas ações"))
        val shortcuts = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        shortcuts.addView(shortcutCard("▶", "REPRODUZIR", "Abrir janela flutuante") { activateFloating() }, LinearLayout.LayoutParams(0, dp(82), 1f))
        shortcuts.addView(shortcutCard("■", "PARAR TUDO", "Interromper os áudios") { sendService(FloatingService.ACTION_STOP_ALL) }, LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(8) })
        shortcuts.addView(shortcutCard("⚙", "AJUSTES", "Personalizar o app") { showSettings() }, LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(8) })
        content.addView(shortcuts)

        content.addView(sectionTitle("FAVORITOS RÁPIDOS", "Toque para reproduzir"))
        val favScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        quickFavorites = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        favScroll.addView(quickFavorites)
        content.addView(favScroll, LinearLayout.LayoutParams(-1, dp(54)))

        content.addView(sectionTitle("MINHA BIBLIOTECA", "Pesquise, organize e gerencie seus áudios"))
        search = EditText(this).apply {
            hint = "⌕  Pesquisar por nome ou categoria"; setSingleLine(true); textSize = 13f
            setTextColor(-1); setHintTextColor(muted); setPadding(dp(14), 0, dp(14), 0)
            background = rounded(card, dp(11))
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(49)))
        search.addTextChangedListener(SimpleWatcher { query = it; refreshLibrary() })

        val filters = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        filters.addView(textAction("TODOS") { favoritesOnly = false; categoryFilter = "Todas"; refreshLibrary() })
        filters.addView(textAction("★ FAVORITOS") { favoritesOnly = !favoritesOnly; refreshLibrary() })
        filters.addView(textAction("CATEGORIAS ▾") { chooseCategory() })
        content.addView(filters)
        libraryTitle = sectionTitle("ÁUDIOS", "Sua coleção completa")
        content.addView(libraryTitle)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(0xFF111511.toInt())
        }
        bottom.addView(textAction("CONFIGURAÇÕES") { showSettings() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        bottom.addView(button("PARAR TODOS") { sendService(FloatingService.ACTION_STOP_ALL) }, LinearLayout.LayoutParams(dp(132), dp(42)))
        root.addView(bottom)
        setContentView(root)
        refreshLibrary()
    }

    private fun metricCard(title: String, value: String): Pair<LinearLayout, TextView> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = rounded(card, dp(12)); setPadding(dp(5), dp(8), dp(5), dp(8))
        }
        val number = label(value, 21f, lime).apply { setTypeface(null, 1) }
        box.addView(number)
        box.addView(label(title, 9f, muted).apply { setPadding(0, dp(2), 0, 0) })
        return box to number
    }

    private fun sectionTitle(title: String, subtitle: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(13), 0, dp(8))
            addView(label(title, 12f, lime).apply { setTypeface(null, 1) })
            addView(label(subtitle, 10f, muted).apply { setPadding(0, dp(2), 0, 0) })
        }
    }

    private fun shortcutCard(symbol: String, title: String, subtitle: String, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(7), dp(4), dp(7)); background = rounded(card, dp(11))
            isClickable = true; isFocusable = true; setOnClickListener { action() }
            addView(label(symbol, 17f, lime).apply { setTypeface(null, 1) })
            addView(label(title, 9f, -1).apply { setTypeface(null, 1); setPadding(0, dp(3), 0, 0) })
            addView(label(subtitle, 7f, muted).apply { gravity = Gravity.CENTER; maxLines = 1 })
        }
    }

    private fun refreshLibrary() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val all = SoundStore.all(this)
        val filtered = all.filter {
            (!favoritesOnly || it.favorite) &&
            (categoryFilter == "Todas" || it.category == categoryFilter) &&
            (it.name.contains(query, true) || it.category.contains(query, true))
        }
        count.text = all.size.toString()
        if (::favoritesCount.isInitialized) favoritesCount.text = all.count { it.favorite }.toString()
        if (::categoriesCount.isInitialized) categoriesCount.text = SoundStore.categories(this).distinct().size.toString()
        if (::quickFavorites.isInitialized) {
            quickFavorites.removeAllViews()
            val favorites = all.filter { it.favorite }.take(12)
            if (favorites.isEmpty()) quickFavorites.addView(label("Marque uma estrela nos áudios para criar atalhos aqui.", 10f, muted).apply { setPadding(dp(4), dp(14), 0, 0) })
            favorites.forEach { sound ->
                val chip = TextView(this).apply {
                    text = "▶  ${sound.name}"; textSize = 10f; setTextColor(lime)
                    setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(card, dp(18))
                    setOnClickListener { sendService(FloatingService.ACTION_PLAY, sound.id) }
                }
                val chipLp = LinearLayout.LayoutParams(-2, dp(40)); chipLp.rightMargin = dp(7)
                quickFavorites.addView(chip, chipLp)
            }
        }
        if (::libraryTitle.isInitialized) {
            libraryTitle.getChildAt(0)?.let { (it as? TextView)?.text = "ÁUDIOS  •  ${filtered.size} EXIBIDOS" }
        }
        if (filtered.isEmpty()) {
            list.addView(label(if (all.isEmpty()) "Sua biblioteca está vazia.\nImporte arquivos de áudio para começar." else "Nenhum áudio encontrado.", 14f, muted).apply {
                gravity = Gravity.CENTER; setPadding(dp(20), dp(38), dp(20), dp(38))
            })
        }
        filtered.forEach { sound ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(11), dp(10), dp(9))
                background = rounded(card, dp(12))
            }
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val play = button("▶") { sendService(FloatingService.ACTION_PLAY, sound.id) }
            line.addView(play, LinearLayout.LayoutParams(dp(48), dp(42)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(4), 0) }
            info.addView(label(sound.name, 14f, -1).apply { maxLines = 1 })
            info.addView(label(sound.category, 10f, muted))
            line.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(textAction(if (sound.favorite) "★" else "☆") {
                SoundStore.update(this, sound.copy(favorite = !sound.favorite)); refreshLibrary()
            })
            line.addView(textAction("⋮") { soundMenu(sound) })
            row.addView(line)
            val sep = View(this).apply { setBackgroundColor(0xFF303830.toInt()) }
            row.addView(sep, LinearLayout.LayoutParams(-1, dp(1)))
            val controls = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            controls.addView(textAction("RENOMEAR") { rename(sound) })
            controls.addView(textAction("CATEGORIA") { changeCategory(sound) })
            controls.addView(textAction("EXCLUIR") { confirmDelete(sound) })
            row.addView(controls)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8)
            list.addView(row, lp)
        }
    }

    private fun soundMenu(s: SoundStore.Sound) {
        val options = arrayOf("Reproduzir", "Renomear", "Alterar categoria", if (s.favorite) "Remover favorito" else "Adicionar favorito", "Excluir")
        AlertDialog.Builder(this).setTitle(s.name).setItems(options) { _, which ->
            when (which) {
                0 -> sendService(FloatingService.ACTION_PLAY, s.id)
                1 -> rename(s)
                2 -> changeCategory(s)
                3 -> { SoundStore.update(this, s.copy(favorite = !s.favorite)); refreshLibrary() }
                4 -> confirmDelete(s)
            }
        }.show()
    }
    private fun rename(s: SoundStore.Sound) {
        val field = EditText(this).apply { setText(s.name); setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Renomear áudio").setView(field)
            .setPositiveButton("SALVAR") { _, _ ->
                val name = field.text.toString().trim()
                if (name.isNotEmpty()) { SoundStore.update(this, s.copy(name = name)); refreshLibrary(); refreshFloating() }
            }.setNegativeButton("CANCELAR", null).show()
    }
    private fun changeCategory(s: SoundStore.Sound) {
        val cats = (SoundStore.categories(this) + "Nova categoria").distinct()
        AlertDialog.Builder(this).setTitle("Categoria").setItems(cats.toTypedArray()) { _, i ->
            if (cats[i] == "Nova categoria") {
                val field = EditText(this).apply { hint = "Nome da categoria" }
                AlertDialog.Builder(this).setTitle("Nova categoria").setView(field)
                    .setPositiveButton("SALVAR") { _, _ ->
                        val name = field.text.toString().trim()
                        if (name.isNotEmpty()) { SoundStore.update(this, s.copy(category = name)); refreshLibrary(); refreshFloating() }
                    }.setNegativeButton("CANCELAR", null).show()
            } else { SoundStore.update(this, s.copy(category = cats[i])); refreshLibrary(); refreshFloating() }
        }.show()
    }
    private fun chooseCategory() {
        val cats = arrayOf("Todas") + SoundStore.categories(this).distinct().toTypedArray()
        AlertDialog.Builder(this).setTitle("Filtrar categoria").setItems(cats) { _, i ->
            categoryFilter = cats[i]; favoritesOnly = false; refreshLibrary()
        }.show()
    }
    private fun confirmDelete(s: SoundStore.Sound) {
        AlertDialog.Builder(this).setTitle("Excluir áudio?")
            .setMessage("“${s.name}” será removido da biblioteca.")
            .setPositiveButton("EXCLUIR") { _, _ ->
                sendService(FloatingService.ACTION_STOP_ONE, s.id)
                SoundStore.delete(this, s.id); refreshLibrary(); refreshFloating()
            }.setNegativeButton("CANCELAR", null).show()
    }
    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(label("Volume padrão", 13f, -1))
        val volume = SeekBar(this).apply { max = 100; progress = SoundStore.volume(this@MainActivity) }
        box.addView(volume)
        box.addView(label("Cor de destaque", 13f, -1).apply { setPadding(0, dp(12), 0, 0) })
        val colors = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Verde-limão", "Azul", "Roxo"))
            setSelection(listOf("lime","blue","purple").indexOf(SoundStore.accent(this@MainActivity)).coerceAtLeast(0))
        }
        box.addView(colors)
        val keep = CheckBox(this).apply {
            text = "Manter bolinha após minimizar"; setTextColor(-1); isChecked = SoundStore.keepBubble(this@MainActivity)
        }
        box.addView(keep)
        volume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) SoundStore.setVolume(this@MainActivity, p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        AlertDialog.Builder(this).setTitle("CONFIGURAÇÕES").setView(box)
            .setPositiveButton("SALVAR") { _, _ ->
                SoundStore.setAccent(this, listOf("lime","blue","purple")[colors.selectedItemPosition])
                SoundStore.setKeepBubble(this, keep.isChecked)
                refreshFloating()
            }.setNegativeButton("FECHAR", null).show()
    }

    private fun activateFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Ative Permitir sobreposição e volte ao app.", Toast.LENGTH_LONG).show()
        } else {
            startServiceCompat(Intent(this, FloatingService::class.java))
            Toast.makeText(this, "Janela flutuante ativada", Toast.LENGTH_SHORT).show()
        }
    }
    private fun refreshFloating() = sendService(FloatingService.ACTION_REFRESH)
    private fun sendService(action: String, id: String? = null) {
        val i = Intent(this, FloatingService::class.java).setAction(action)
        if (id != null) i.putExtra(FloatingService.EXTRA_ID, id)
        startServiceCompat(i)
    }
    private fun startServiceCompat(i: Intent) {
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 11f; isAllCaps = false; setTextColor(0xFF080A08.toInt())
        background = rounded(lime, dp(10)); setPadding(dp(8), 0, dp(8), 0); setOnClickListener { action() }
    }
    private fun textAction(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 10f; setTextColor(lime); setTypeface(null, 1)
        gravity = Gravity.CENTER; setPadding(dp(9), dp(8), dp(9), dp(8)); setOnClickListener { action() }
    }
    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}


private class SimpleWatcher(private val changed: (String) -> Unit) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        changed(s?.toString().orEmpty())
    }
    override fun afterTextChanged(s: Editable?) {}
}
