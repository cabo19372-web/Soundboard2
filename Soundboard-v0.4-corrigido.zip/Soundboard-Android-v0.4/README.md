# Soundboard Android — versão 0.4

Projeto Android nativo em Kotlin. Package: `com.soundboard.app`. Preparado para compilação Debug pelo GitHub Actions usando Java 17 e Gradle 8.7.

## Novidades da versão 0.4
- Interface inicial reformulada com painel de destaque, indicadores de biblioteca e atalhos.
- Área de favoritos rápidos: toque em um favorito para reproduzi-lo sem procurar na lista.
- Biblioteca com pesquisa, filtros, edição de nome/categoria e exclusão.
- Importação de múltiplos arquivos de áudio.
- Mantidas as funções de reprodução simultânea e janela flutuante da versão 0.3.
- Mantidos os controles de parar todos, minimizar e encerrar janela.
- Mantidas as configurações de volume, cor de destaque e permanência da bolinha.
- Package preservado: `com.soundboard.app`; versionCode 4; versionName 0.4.

## Compatibilidade e limitações
- minSdk 23, targetSdk 35, Java 17, Android Gradle Plugin 8.6.1, Kotlin 2.0.21.
- A biblioteca guarda URIs persistentes concedidas pelo seletor de documentos. Se o arquivo original for apagado/movido ou o acesso for revogado pelo Android, aquele áudio pode deixar de abrir.
- A reprodução simultânea depende da memória, dos decodificadores e dos formatos suportados pelo Android.
- O áudio é reproduzido na saída de áudio do aparelho. O Android não oferece a um app comum um microfone virtual que injete automaticamente o som em Roblox/Discord/voice chat.
- A aparência padrão usa fundo preto e verde-limão; há opções de azul e roxo nas configurações.
- **O APK não foi compilado nem testado em aparelho nesta entrega.** A compilação real deve ser confirmada no GitHub Actions.

## Como atualizar pelo celular
1. Baixe e extraia o ZIP.
2. Substitua o conteúdo do repositório `cabo19372-web/Soundboard2` pelos arquivos do ZIP, incluindo `.github/workflows/`.
3. Faça commit na branch `main`.
4. Abra **Actions** → **Build Soundboard APK** → **Run workflow**.
5. Baixe o artefato **Soundboard-v0.4-debug-apk** e extraia `app-debug.apk`.
6. Instale por cima da versão anterior. Se houver conflito de assinatura, será necessário desinstalar a versão antiga; isso apaga os dados locais, então faça backup antes.

## Primeiro uso
1. Importe seus áudios pelo botão **IMPORTAR ÁUDIOS**.
2. Marque a estrela dos sons que deseja deixar nos favoritos rápidos.
3. Use **JANELA S** para ativar a bolinha flutuante (conceda a permissão de sobreposição quando solicitada).
4. Reproduza sons pela biblioteca ou pelo painel flutuante.
