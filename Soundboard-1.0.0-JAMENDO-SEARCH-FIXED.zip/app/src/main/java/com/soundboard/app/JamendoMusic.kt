package com.soundboard.app

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Read-only Jamendo catalog client. Streaming URLs are supplied by Jamendo itself. */
data class JamendoTrack(
    val id: String,
    val name: String,
    val artist: String,
    val album: String,
    val image: String,
    val audio: String,
    val downloadAllowed: Boolean
)

object JamendoMusic {
    private const val CLIENT_ID = "2ccd827a"

    fun search(term: String): List<JamendoTrack> {
        if (term.isBlank()) return emptyList()
        val encoded = URLEncoder.encode(term.trim(), "UTF-8")
        val address = "https://api.jamendo.com/v3.0/tracks/?client_id=$CLIENT_ID&format=json&limit=25&type=single+albumtrack&audioformat=mp32&search=$encoded"
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) return emptyList()
            val root = JSONObject(body)
            if (root.optJSONObject("headers")?.optString("status") != "success") return emptyList()
            val rows = root.optJSONArray("results") ?: return emptyList()
            buildList {
                for (i in 0 until rows.length()) {
                    val item = rows.optJSONObject(i) ?: continue
                    val audio = item.optString("audio")
                    if (audio.isBlank() || audio == "null") continue
                    add(JamendoTrack(
                        id = item.optString("id"),
                        name = item.optString("name", "Faixa sem título"),
                        artist = item.optString("artist_name", "Artista desconhecido"),
                        album = item.optString("album_name", ""),
                        image = item.optString("image", ""),
                        audio = audio,
                        downloadAllowed = item.optBoolean("audiodownload_allowed", false)
                    ))
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    fun uri(track: JamendoTrack): Uri = Uri.parse(track.audio)
}
