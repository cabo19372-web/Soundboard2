# Soundboard Android 0.8 — Blue Edition

Projeto Android nativo em Kotlin. Esta versão foi construída sobre o código-fonte 0.7, preservando a biblioteca de áudios, reprodução, janela flutuante, Audio Studio e processamento WAV já existentes.

## Identidade Blue Edition
- Fundo principal preto `#050608`.
- Cartões grafite `#11151D`.
- Azul elétrico `#0865FF` para botões, ícones, seleções e destaques.
- Texto principal `#F4F4F5`.
- Ícone próprio do aplicativo.

## Atualização visual Blue Edition (mantém 0.8)
- Interface principal reorganizada com cabeçalho, categorias horizontais, pesquisa, biblioteca em duas colunas, mini-reprodutor e navegação inferior.
- Mascote oficial Blue Edition integrado ao cabeçalho e ao ícone do aplicativo usando o PNG enviado.
- Categorias rápidas: Todos, Memes, Jogos, Músicas e Favoritos.
- Histórico local das últimas reproduções e tela Sobre.
- Vídeo de abertura fornecido integrado à Splash Screen nativa; o trecho de apresentação da marca é reproduzido sem áudio e a tela principal aparece ao final ou ao tocar para pular.
- Tratamento de Window Insets com WindowCompat/WindowInsetsCompat para reservar as barras de status e navegação em navegação por gestos ou três botões.
- Package `com.soundboard.app`, `versionCode 8` e `versionName 0.8` preservados.
- GitHub Actions publica o artefato `Soundboard-v0.8-debug-apk`.

## Atualização com os arquivos enviados
- `wolf_mascot.png`: mascote azul oficial aplicado no cabeçalho e no ícone do app.
- `soundboard_intro.mp4`: animação de abertura integrada em `res/raw`; foi recortado o trecho inicial de 4,6 segundos para retirar a parte final de créditos do vídeo original.
- A interface foi aproximada da captura de referência: cabeçalho compacto, importação e configurações no topo, categorias horizontais, busca, cartões de áudio compactos, mini-reprodutor e navegação inferior.

## Observações desta atualização
- O modelo de dados atual não possui campo de tags por áudio; a pesquisa desta entrega cobre nome e categoria.
- A barra inferior oferece seleção de áudio, pausar/continuar via serviço e parar. O serviço atual não expõe posição/duração ao Activity, então não foi inventada uma porcentagem de progresso sincronizada.
- A compilação e o teste físico no Galaxy A06 ainda precisam ser confirmados pelo GitHub Actions e no aparelho.

## Funcionalidades preservadas da 0.7
- Importação de múltiplos arquivos de áudio.
- Biblioteca dinâmica, pesquisa, categorias, renomeação, exclusão e favoritos.
- Janela flutuante com pesquisa, reprodução e ação PARAR TODOS.
- Reprodução simultânea por instâncias independentes de MediaPlayer.
- Volume geral, BassBoost, amplificação digital e equalizador de cinco bandas, conforme suporte do Android.
- Limite simples de volume de saída.
- Redução de ruído tipo noise gate para WAV PCM 16-bit mono/estéreo durante importação.

## Limitações / itens ainda não implementados nesta entrega
A 0.8 não implementa ainda todos os recursos listados como desejados para versões futuras. Permanecem pendentes: fotos/capas por áudio, tags personalizadas, organização manual por arrastar, favoritos em páginas deslizáveis na janela, transparência/encaixe automático/redimensionamento avançado, volume individual por som, fila/sequência/aleatório, normalização, gravação pelo microfone, medidor visual, perfis por jogo, widget Android, atalho nas configurações rápidas, extração de áudio de vídeo, backup completo e detecção de duplicados.

## Compilação pelo GitHub Actions
1. Extraia o conteúdo deste ZIP diretamente na raiz do repositório GitHub (as pastas `app/` e `.github/` devem ficar diretamente na raiz).
2. Faça commit e push na branch `main`.
3. Abra a aba **Actions** e execute **Build Soundboard APK** (ou aguarde o build automático após o push).
4. Baixe o artefato `Soundboard-v0.8-debug-apk`.

## Identificação
- Package: `com.soundboard.app`
- versionCode: `8`
- versionName: `0.8`
- SDK de compilação: 35
- Min SDK: 23

**Nota:** o ZIP foi verificado estruturalmente. A compilação Android e o teste no Samsung Galaxy A06 ainda precisam ser confirmados pelo GitHub Actions e no próprio aparelho.
