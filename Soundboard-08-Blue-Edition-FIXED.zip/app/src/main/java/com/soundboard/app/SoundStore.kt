package com.soundboard.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Persistent, dynamically-sized audio library. */
object SoundStore {
    private const val PREFS = "soundboard_v03"
    private const val KEY_SOUNDS = "sounds"
    private const val KEY_VOLUME = "volume"
    private const val KEY_ACCENT = "accent"
    private const val KEY_KEEP_BUBBLE = "keep_bubble"
    private const val KEY_BASS = "bass_strength"
    private const val KEY_BOOST = "loudness_boost"
    private const val KEY_EQ = "eq_band_"
    private const val KEY_SAFE_LIMIT = "safe_volume_limit"
    private const val KEY_DENOISE = "denoise_enabled"
    private const val KEY_DENOISE_STRENGTH = "denoise_strength"
    private const val KEY_GRID_COLUMNS = "grid_columns"
    private const val KEY_BUTTON_SCALE = "button_scale"

    data class Sound(
        val id: String,
        val uri: String,
        val name: String,
        val category: String = "Geral",
        val favorite: Boolean = false
    )

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun all(c: Context): MutableList<Sound> {
        val raw = prefs(c).getString(KEY_SOUNDS, "[]") ?: "[]"
        val out = mutableListOf<Sound>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Sound(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.optString("uri"), o.optString("name", "Áudio"),
                    o.optString("category", "Geral"), o.optBoolean("favorite", false)
                ))
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized private fun save(c: Context, sounds: List<Sound>) {
        val arr = JSONArray()
        sounds.forEach { s ->
            arr.put(JSONObject().put("id", s.id).put("uri", s.uri)
                .put("name", s.name).put("category", s.category).put("favorite", s.favorite))
        }
        prefs(c).edit().putString(KEY_SOUNDS, arr.toString()).apply()
    }

    fun add(c: Context, uri: Uri, name: String): Sound {
        val item = Sound(UUID.randomUUID().toString(), uri.toString(), name.ifBlank { "Novo áudio" })
        val list = all(c); list.add(item); save(c, list); return item
    }
    fun update(c: Context, item: Sound) {
        val list = all(c); val i = list.indexOfFirst { it.id == item.id }
        if (i >= 0) { list[i] = item; save(c, list) }
    }
    fun delete(c: Context, id: String) { save(c, all(c).filterNot { it.id == id }) }
    fun get(c: Context, id: String): Sound? = all(c).firstOrNull { it.id == id }
    fun categories(c: Context): List<String> =
        listOf("Geral", "Efeitos", "Memes", "Música", "Vozes", "Outros") +
            all(c).map { it.category }.filter { it.isNotBlank() }.distinct()

    fun volume(c: Context) = prefs(c).getInt(KEY_VOLUME, 75)
    fun setVolume(c: Context, value: Int) { prefs(c).edit().putInt(KEY_VOLUME, value.coerceIn(0,100)).apply() }
    fun accent(c: Context) = "blue"
    fun setAccent(c: Context, value: String) { prefs(c).edit().putString(KEY_ACCENT, "blue").apply() }
    fun gridColumns(c: Context) = prefs(c).getInt(KEY_GRID_COLUMNS, 2).coerceIn(2, 4)
    fun setGridColumns(c: Context, value: Int) { prefs(c).edit().putInt(KEY_GRID_COLUMNS, value.coerceIn(2, 4)).apply() }
    fun buttonScale(c: Context) = prefs(c).getInt(KEY_BUTTON_SCALE, 100).coerceIn(75, 125)
    fun setButtonScale(c: Context, value: Int) { prefs(c).edit().putInt(KEY_BUTTON_SCALE, value.coerceIn(75, 125)).apply() }
    fun keepBubble(c: Context) = prefs(c).getBoolean(KEY_KEEP_BUBBLE, true)
    fun setKeepBubble(c: Context, value: Boolean) { prefs(c).edit().putBoolean(KEY_KEEP_BUBBLE, value).apply() }
    fun bass(c: Context) = prefs(c).getInt(KEY_BASS, 0)
    fun setBass(c: Context, value: Int) { prefs(c).edit().putInt(KEY_BASS, value.coerceIn(0, 1000)).apply() }
    fun boost(c: Context) = prefs(c).getInt(KEY_BOOST, 0)
    fun setBoost(c: Context, value: Int) { prefs(c).edit().putInt(KEY_BOOST, value.coerceIn(0, 600)).apply() }
    fun eqBand(c: Context, band: Int) = prefs(c).getInt(KEY_EQ + band.coerceIn(0, 4), 0)
    fun setEqBand(c: Context, band: Int, value: Int) {
        prefs(c).edit().putInt(KEY_EQ + band.coerceIn(0, 4), value.coerceIn(-12, 12)).apply()
    }
    fun denoiseEnabled(c: Context) = prefs(c).getBoolean(KEY_DENOISE, false)
    fun setDenoiseEnabled(c: Context, value: Boolean) { prefs(c).edit().putBoolean(KEY_DENOISE, value).apply() }
    fun denoiseStrength(c: Context) = prefs(c).getInt(KEY_DENOISE_STRENGTH, 55)
    fun setDenoiseStrength(c: Context, value: Int) { prefs(c).edit().putInt(KEY_DENOISE_STRENGTH, value.coerceIn(0, 100)).apply() }
    fun safeLimit(c: Context) = prefs(c).getBoolean(KEY_SAFE_LIMIT, true)
    fun setSafeLimit(c: Context, value: Boolean) { prefs(c).edit().putBoolean(KEY_SAFE_LIMIT, value).apply() }
}
