package com.soundboard.app

import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Basic offline noise gate for uncompressed PCM 16-bit WAV files. Not AI denoising. */
object WavNoiseReducer {
    data class Result(val bytes: ByteArray?, val reason: String? = null)

    fun process(input: ByteArray, strength: Int): Result {
        if (input.size < 44 || ascii(input, 0, 4) != "RIFF" || ascii(input, 8, 4) != "WAVE")
            return Result(null, "Formato não WAV")
        var pos = 12
        var dataOffset = -1
        var dataSize = 0
        var channels = 0
        var bits = 0
        var format = 0
        while (pos + 8 <= input.size) {
            val id = ascii(input, pos, 4)
            val size = u32(input, pos + 4).coerceAtMost((input.size - pos - 8).toLong()).toInt()
            val start = pos + 8
            when (id) {
                "fmt " -> if (size >= 16) {
                    format = u16(input, start); channels = u16(input, start + 2); bits = u16(input, start + 14)
                }
                "data" -> { dataOffset = start; dataSize = size; break }
            }
            pos = start + size + (size and 1)
        }
        if (format != 1 || bits != 16 || channels !in 1..2 || dataOffset < 0)
            return Result(null, "WAV precisa ser PCM 16-bit mono ou estéreo")
        val out = input.copyOf()
        val samples = dataSize / 2
        if (samples < 128) return Result(null, "Áudio muito curto")
        // Estimate a conservative noise floor from the quietest 20% of short-window RMS values.
        val window = max(64, 2048 / channels)
        val rmsValues = ArrayList<Double>()
        var cursor = 0
        while (cursor < samples) {
            val end = min(samples, cursor + window)
            var sum = 0.0
            for (i in cursor until end) { val v = readS16(input, dataOffset + i * 2) / 32768.0; sum += v * v }
            rmsValues.add(kotlin.math.sqrt(sum / max(1, end - cursor)))
            cursor = end
        }
        val sorted = rmsValues.sorted()
        val floor = sorted[(sorted.size * 0.20).toInt().coerceIn(0, sorted.lastIndex)]
        val threshold = (floor * (1.25 + strength.coerceIn(0,100) / 35.0) + 0.0015).coerceIn(0.002, 0.12)
        val attack = 0.22
        val release = 0.035
        var envelope = 0.0
        for (i in 0 until samples) {
            val offset = dataOffset + i * 2
            val sample = readS16(input, offset)
            val level = abs(sample / 32768.0)
            envelope = if (level > envelope) envelope + (level - envelope) * attack else envelope + (level - envelope) * release
            val gate = when {
                envelope <= threshold * 0.55 -> 0.0
                envelope >= threshold -> 1.0
                else -> { val x = (envelope - threshold * 0.55) / (threshold * 0.45); x * x * (3.0 - 2.0 * x) }
            }
            writeS16(out, offset, (sample * gate).toInt().coerceIn(-32768, 32767))
        }
        return Result(out)
    }

    private fun ascii(b: ByteArray, o: Int, n: Int) = String(b, o, n, Charsets.US_ASCII)
    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o+1].toInt() and 255) shl 8)
    private fun u32(b: ByteArray, o: Int) = (u16(b,o).toLong() or (u16(b,o+2).toLong() shl 16))
    private fun readS16(b: ByteArray, o: Int) = (b[o].toInt() and 255) or (b[o+1].toInt() shl 8)
    private fun writeS16(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o+1] = (v shr 8).toByte() }
}
