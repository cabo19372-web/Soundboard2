# Soundboard Android — versão 0.3

Projeto Android nativo em Kotlin. Package: `com.soundboard.app`. Preparado para compilação Debug pelo GitHub Actions usando Java 17 e Gradle 8.7.

## Novidades da versão 0.3
- Biblioteca dinâmica: importe vários arquivos de áudio de uma só vez, sem limite fixo de oito slots.
- Pesquisa por nome/categoria, filtro de favoritos e filtro de categoria.
- Favoritar, renomear, categorizar e excluir cada áudio.
- Reprodução simultânea de vários arquivos com players independentes.
- Janela flutuante com bolinha “S” arrastável.
- Painel com pesquisa, controles individuais, volume geral e PARAR TODOS.
- Minimizar recolhe o painel e mantém a bolinha.
- ENCERRAR JANELA fecha o serviço, remove a bolinha e interrompe todos os sons.
- Animações de entrada/saída.
- Configurações de volume padrão, cor de destaque e permanência da bolinha.
- Mantém o package `com.soundboard.app` e atualiza versionCode/versionName para 3/0.3.

## Compatibilidade e limitações
- minSdk 23, targetSdk 35, Java 17, Android Gradle Plugin 8.6.1, Kotlin 2.0.21.
- A biblioteca guarda URIs persistentes concedidas pelo seletor de documentos. Se o arquivo original for apagado/movido ou o acesso for revogado pelo Android, aquele áudio pode deixar de abrir.
- A reprodução simultânea depende da memória, dos decodificadores e dos formatos suportados pelo Android.
- O áudio é reproduzido na saída de áudio do aparelho. O Android não oferece a um app comum um microfone virtual que injete automaticamente o som em Roblox/Discord/voice chat.
- A aparência foi preparada para fundo preto e destaque verde-limão; há opções de azul e roxo nas configurações.
- **Não afirmamos que o APK foi compilado nem testado em aparelho nesta entrega.** A compilação real deve ser confirmada no GitHub Actions.

## Como atualizar o repositório pelo celular
1. Baixe e extraia este ZIP.
2. Abra o repositório `cabo19372-web/Soundboard2` no GitHub.
3. Substitua o conteúdo antigo pela estrutura completa deste ZIP. Envie também a pasta oculta `.github/workflows/` (ela contém o workflow atualizado).
4. Faça commit na branch `main`.
5. Abra **Actions** → **Build Soundboard APK** → **Run workflow**.
6. Aguarde o job terminar. Baixe o artefato **Soundboard-v0.3-debug-apk** e extraia `app-debug.apk`.
7. Instale por cima da versão anterior, mantendo o mesmo package. Se o Android informar conflito de assinatura, desinstale a versão antiga e instale o novo APK; nesse caso, faça backup dos dados antes, pois a desinstalação apaga os dados locais do app.

## Primeiro uso
1. Abra o Soundboard e toque em **JANELA S** ou importe sons pela biblioteca.
2. Na primeira ativação, permita a sobreposição sobre outros apps.
3. Toque na bolinha **S** para abrir o painel.
4. Use **+ IMPORTAR ÁUDIOS** para selecionar vários arquivos de uma vez.
5. Pesquise, favorite, renomeie, categorize ou exclua sons pela tela principal.
6. No painel flutuante, toque em ▶ para reproduzir; sons diferentes podem tocar simultaneamente.
7. Use **PARAR TODOS**, **MINIMIZAR** ou **ENCERRAR JANELA** conforme necessário.
