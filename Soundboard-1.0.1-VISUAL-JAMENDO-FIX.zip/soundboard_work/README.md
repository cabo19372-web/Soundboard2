# Soundboard 1.0.0 Premium — correção da bolinha animada

Esta entrega reforça a animação da bolinha flutuante durante a reprodução:
- pulsação contínua e mais perceptível;
- leve inclinação alternada;
- contorno elétrico azul/ciano variável;
- brilho externo pulsante;
- ícone musical durante a reprodução;
- retorno ao estado normal quando todos os sons param.

O ajuste foi feito em `FloatingService.kt`. O fluxo de reprodução e os arquivos do motor de áudio foram preservados.

## Compilação

Projeto Android Kotlin. Execute `gradle --no-daemon clean assembleDebug` em um ambiente com Android SDK e Gradle configurados. O APK não foi compilado/verificado neste ambiente, pois não há Gradle nem Android SDK configurados.

## Pesquisa online com Jamendo

A janela flutuante agora pesquisa simultaneamente na biblioteca local e no catálogo Jamendo quando a busca tem pelo menos 2 caracteres. Os resultados online podem ser reproduzidos por streaming ou salvos na biblioteca/favoritos do Soundboard. As faixas salvas como favoritas/lista guardam o endereço de streaming; a reprodução dessas faixas requer conexão com a internet.

O aplicativo usa o Client ID Jamendo informado pelo proprietário do projeto (`2ccd827a`) e a API v3.0 somente para leitura. O ID é identificador público da aplicação, não é senha nem `client_secret`. A permissão INTERNET foi adicionada ao Manifest. A reprodução online usa o MediaPlayer já existente no serviço flutuante, mantendo a cadeia de efeitos de áudio do Soundboard.

A busca online retorna o catálogo independente do Jamendo; ela não é uma busca do Google/YouTube e não promete encontrar todas as músicas comerciais.

## Verificação desta entrega

O ZIP foi validado estruturalmente (`unzip -t`). Não foi possível executar `assembleDebug` neste ambiente porque não há Android SDK nem Gradle instalados; portanto, esta entrega é o projeto-fonte atualizado, não um APK compilado.
