package com.soundboard.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ValueAnimator
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.widget.*
import kotlin.math.abs
import java.util.concurrent.Executors

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: ElectricBubbleView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var expanded = false
    private val players = mutableMapOf<String, MediaPlayer>()
    private val bassEffects = mutableMapOf<String, BassBoost>()
    private val loudnessEffects = mutableMapOf<String, LoudnessEnhancer>()
    private val equalizers = mutableMapOf<String, Equalizer>()
    private var volume = 75
    private val activeIds = mutableSetOf<String>()
    private var bubblePulse: ValueAnimator? = null
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var onlineResults: List<JamendoTrack> = emptyList()
    private var onlineSearchToken = 0
    private var onlineSearchStatus: TextView? = null
    private var panelSearchQuery = ""
    private var panelMode = "TODOS"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        volume = SoundStore.volume(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (android.provider.Settings.canDrawOverlays(this)) createBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> intent.getStringExtra(EXTRA_ID)?.let { play(it) }
            ACTION_STOP_ONE -> intent.getStringExtra(EXTRA_ID)?.let { stopOne(it) }
            ACTION_STOP_ALL -> stopAll()
            ACTION_REFRESH -> { volume = SoundStore.volume(this); applyAllEffects(); refreshPanel() }
            ACTION_MINIMIZE -> minimize()
            ACTION_CLOSE -> { stopAll(); stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    private fun accent(): Int = 0xFF0865FF.toInt()
    private fun createBubble() {
        if (bubble != null) return
        bubbleParams = WindowManager.LayoutParams(dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(180)
        }
        bubble = ElectricBubbleView(this).apply {
            elevation = dp(8).toFloat()
            setOnClickListener { if (expanded) minimize() else showPanel() }
            setOnTouchListener(dragListener())
        }
        wm.addView(bubble, bubbleParams)
        updateBubbleVisuals()
        bubble?.alpha = 0f
        bubble?.animate()?.alpha(1f)?.setDuration(180)?.start()
    }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(5, 6, 8)); cornerRadius = dp(17).toFloat()
                setStroke(dp(1), accent())
            }
            elevation = dp(14).toFloat()
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "SOUNDBOARD  /  1.0.0 PREMIUM"; textSize = 13f; setTypeface(null, Typeface.BOLD)
            setTextColor(accent())
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(textButton("MINIMIZAR") { minimize() })
        root.addView(header)

        val search = EditText(this).apply {
            hint = "Pesquisar áudio"; textSize = 12f; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(0xFF9299A6.toInt())
            setPadding(dp(9), 0, dp(9), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF11151D.toInt()); cornerRadius = dp(8).toFloat()
            }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(40)))
        onlineSearchStatus = TextView(this).apply {
            text = if (onlineResults.isEmpty()) "Pesquise no celular e na internet" else "${onlineResults.size} faixa(s) online"
            textSize = 8f; setTextColor(0xFF9299A6.toInt()); setPadding(dp(3), dp(5), 0, dp(3))
        }
        root.addView(onlineSearchStatus)
        search.setText(panelSearchQuery)
        val scroll = ScrollView(this)
        val sounds = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(sounds)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(220)))
        fun populate(filter: String = "") {
            sounds.removeAllViews()
            SoundStore.all(this).filter {
                (panelMode != "FAVORITOS" || it.favorite) &&
                    (it.name.contains(filter, true) || it.category.contains(filter, true))
            }.forEach { s ->
                    val line = LinearLayout(this).apply {
                        gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4))
                    }
                    val playButton = actionButton(if (players.containsKey(s.id)) "Ⅱ" else "▶") { play(s.id); refreshPanel() }
                    line.addView(playButton, LinearLayout.LayoutParams(dp(43), dp(39)))
                    val name = TextView(this).apply {
                        text = s.name; textSize = 11f; setTextColor(Color.WHITE); maxLines = 2
                        setPadding(dp(8), 0, dp(3), 0)
                    }
                    line.addView(name, LinearLayout.LayoutParams(0, dp(39), 1f))
                    line.addView(textButton("★") {
                        SoundStore.update(this@FloatingService, s.copy(favorite = !s.favorite)); refreshPanel()
                    })
                    sounds.addView(line)
                    val divider = View(this).apply { setBackgroundColor(0xFF252C38.toInt()) }
                    sounds.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
                }
            if (sounds.childCount == 0) sounds.addView(TextView(this).apply {
                text = "Nenhum áudio na biblioteca"; textSize = 11f; setTextColor(0xFF9AA398.toInt())
                gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20))
            })
            if (filter.trim().length >= 2) {
                sounds.addView(TextView(this).apply {
                    text = "RESULTADOS ONLINE • JAMENDO"; textSize = 9f; setTypeface(null, Typeface.BOLD)
                    setTextColor(accent()); setPadding(dp(2), dp(13), 0, dp(5))
                })
                onlineResults.forEach { track ->
                    val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
                    line.addView(actionButton(if (activeIds.contains("jamendo_${track.id}")) "Ⅱ" else "▶") {
                        playOnline(track); refreshPanel()
                    }, LinearLayout.LayoutParams(dp(40), dp(38)))
                    val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), 0, dp(3), 0) }
                    details.addView(TextView(this).apply { text = track.name; textSize = 10f; maxLines = 1; setTextColor(Color.WHITE) })
                    details.addView(TextView(this).apply { text = track.artist; textSize = 8f; maxLines = 1; setTextColor(0xFF9299A6.toInt()) })
                    line.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
                    line.addView(textButton("⋯") { showOnlineOptions(track) })
                    sounds.addView(line)
                    sounds.addView(View(this).apply { setBackgroundColor(0xFF252C38.toInt()) }, LinearLayout.LayoutParams(-1, dp(1)))
                }
                if (onlineResults.isEmpty()) sounds.addView(TextView(this).apply {
                    text = onlineSearchStatus?.text ?: "Pesquisando no Jamendo…"; textSize = 9f
                    setTextColor(0xFF9299A6.toInt()); setPadding(dp(3), dp(8), 0, dp(8))
                })
            }
        }
        val tabs = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) }
        listOf("TODOS", "MINHA LISTA", "FAVORITOS").forEach { mode ->
            tabs.addView(textButton(mode) {
                panelMode = mode
                populate(panelSearchQuery)
                refreshPanel()
            }, LinearLayout.LayoutParams(0, dp(34), 1f))
        }
        root.addView(tabs)
        populate(panelSearchQuery)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val term = s?.toString().orEmpty()
                panelSearchQuery = term
                onlineResults = emptyList()
                populate(term)
                if (term.trim().length >= 2) searchJamendo(term) else { onlineSearchToken++; onlineSearchStatus?.text = "" }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        val stop = actionButton("PARAR TODOS") { stopAll(); refreshPanel() }
        root.addView(stop, LinearLayout.LayoutParams(-1, dp(42)))
        val volumeTitle = TextView(this).apply {
            text = "VOLUME GERAL  •  $volume%"; textSize = 10f; setTextColor(accent())
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(volumeTitle)
        root.addView(SeekBar(this).apply {
            max = 100; progress = volume
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    volume = p; SoundStore.setVolume(this@FloatingService, p)
                    players.values.toList().forEach { try { it.setVolume(p / 100f, p / 100f) } catch (_: Exception) {} }
                    volumeTitle.text = "VOLUME GERAL  •  $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        val footer = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        footer.addView(textButton("ABRIR APP") {
            val i = Intent(this@FloatingService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        footer.addView(textButton("ENCERRAR JANELA") { stopAll(); stopSelf() })
        root.addView(footer)

        val panelWidth = (resources.displayMetrics.widthPixels - dp(28)).coerceAtMost(dp(286))
        val p = WindowManager.LayoutParams(panelWidth, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            x = (bubbleParams?.x ?: dp(12)).coerceAtMost(resources.displayMetrics.widthPixels - panelWidth).coerceAtLeast(0)
            y = ((bubbleParams?.y ?: dp(180)) + dp(62)).coerceAtMost(resources.displayMetrics.heightPixels - dp(390)).coerceAtLeast(dp(8))
        }
        panel = root
        wm.addView(root, p)
        expanded = true
        root.alpha = 0f; root.scaleX = .94f; root.scaleY = .94f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(190)
            .setInterpolator(AccelerateDecelerateInterpolator()).start()
    }

    private fun searchJamendo(term: String) {
        val token = ++onlineSearchToken
        onlineSearchStatus?.text = "Pesquisando no Jamendo…"
        networkExecutor.execute {
            val result = try { JamendoMusic.search(term) } catch (_: Exception) { emptyList() }
            mainHandler.post {
                if (token != onlineSearchToken || panel == null) return@post
                onlineResults = result
                onlineSearchStatus?.text = if (result.isEmpty()) "Nenhuma faixa online encontrada." else "${result.size} faixa(s) encontrada(s) • Jamendo"
                refreshPanel()
            }
        }
    }

    private fun showOnlineOptions(track: JamendoTrack) {
        AlertDialog.Builder(this)
            .setTitle(track.name)
            .setMessage("${track.artist}\n\nFaixa independente fornecida pelo Jamendo.")
            .setItems(arrayOf("Reproduzir", "Adicionar à minha lista", "Favoritar")) { _, which ->
                when (which) {
                    0 -> playOnline(track)
                    1 -> saveOnlineTrack(track, false)
                    2 -> saveOnlineTrack(track, true)
                }
            }.show()
    }

    private fun saveOnlineTrack(track: JamendoTrack, favorite: Boolean) {
        val existing = SoundStore.all(this).firstOrNull { it.uri == track.audio }
        if (existing != null) {
            if (favorite && !existing.favorite) SoundStore.update(this, existing.copy(favorite = true))
            Toast.makeText(this, if (favorite) "Adicionada aos favoritos" else "Já está na sua lista", Toast.LENGTH_SHORT).show()
        } else {
            val item = SoundStore.add(this, JamendoMusic.uri(track), "${track.name} — ${track.artist}")
            if (favorite) SoundStore.update(this, item.copy(favorite = true))
            Toast.makeText(this, if (favorite) "Música favoritada" else "Música adicionada à lista", Toast.LENGTH_SHORT).show()
        }
        refreshPanel()
    }

    private fun playOnline(track: JamendoTrack) {
        val id = "jamendo_${track.id}"
        val active = players[id]
        if (active != null) {
            try {
                if (active.isPlaying) { active.pause(); activeIds.remove(id) }
                else { active.start(); activeIds.add(id) }
                updateBubbleVisuals(); return
            } catch (_: Exception) { stopOne(id) }
        }
        try {
            val mp = MediaPlayer()
            players[id] = mp
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            mp.setDataSource(track.audio)
            val output = if (SoundStore.safeLimit(this)) volume.coerceAtMost(85) else volume
            mp.setVolume(output / 100f, output / 100f)
            mp.setOnPreparedListener { player ->
                try {
                    attachAudioEffects(id, player.audioSessionId)
                    player.start(); activeIds.add(id); updateBubbleVisuals()
                } catch (_: Exception) { stopOne(id) }
            }
            mp.setOnCompletionListener { stopOne(id); if (expanded) refreshPanel() }
            mp.setOnErrorListener { _, _, _ ->
                stopOne(id)
                Toast.makeText(this, "Não foi possível transmitir essa faixa. Tente outra música.", Toast.LENGTH_LONG).show()
                true
            }
            mp.prepareAsync()
        } catch (_: Exception) {
            stopOne(id)
            Toast.makeText(this, "Falha ao abrir a transmissão do Jamendo.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun play(id: String) {
        val active = players[id]
        if (active != null) {
            try {
                if (active.isPlaying) { active.pause(); activeIds.remove(id); updateBubbleVisuals(); return }
                active.start(); activeIds.add(id); updateBubbleVisuals(); return
            } catch (_: Exception) { stopOne(id) }
        }
        val sound = SoundStore.get(this, id) ?: return
        try {
            val mp = MediaPlayer()
            players[id] = mp
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            mp.setDataSource(this, Uri.parse(sound.uri))
            val output = if (SoundStore.safeLimit(this)) volume.coerceAtMost(85) else volume
            mp.setVolume(output / 100f, output / 100f)
            mp.setOnPreparedListener { player ->
                try {
                    attachAudioEffects(id, player.audioSessionId)
                    player.start()
                    activeIds.add(id)
                    updateBubbleVisuals()
                } catch (_: Exception) { stopOne(id) }
            }
            mp.setOnCompletionListener { stopOne(id); if (expanded) refreshPanel() }
            mp.setOnErrorListener { _, _, _ -> stopOne(id); true }
            mp.prepareAsync()
        } catch (_: Exception) {
            stopOne(id); Toast.makeText(this, "Não foi possível reproduzir ${sound.name}.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun attachAudioEffects(id: String, sessionId: Int) {
        releaseEffects(id)
        val bassLevel = SoundStore.bass(this)
        val gain = SoundStore.boost(this)
        val eqValues = (0..4).map { SoundStore.eqBand(this, it) }
        if (bassLevel > 0) try {
            val effect = BassBoost(0, sessionId)
            effect.setStrength(bassLevel.toShort())
            effect.enabled = true
            bassEffects[id] = effect
        } catch (_: Exception) {}
        if (gain > 0) try {
            val effect = LoudnessEnhancer(sessionId)
            effect.setTargetGain(gain * 10)
            effect.enabled = true
            loudnessEffects[id] = effect
        } catch (_: Exception) {}
        if (eqValues.any { it != 0 }) try {
            val effect = Equalizer(0, sessionId)
            effect.enabled = true
            val bands = effect.numberOfBands.toInt().coerceAtMost(5)
            for (band in 0 until bands) {
                val sourceIndex = if (bands == 1) 2 else (band * 4 / (bands - 1))
                val range = effect.bandLevelRange
                val requested = eqValues[sourceIndex] * 100
                val level = requested.coerceIn(range[0].toInt(), range[1].toInt()).toShort()
                effect.setBandLevel(band.toShort(), level)
            }
            equalizers[id] = effect
        } catch (_: Exception) {}
    }
    private fun applyAllEffects() {
        players.forEach { (id, player) ->
            val output = if (SoundStore.safeLimit(this)) volume.coerceAtMost(85) else volume
            try { player.setVolume(output / 100f, output / 100f) } catch (_: Exception) {}
            try { attachAudioEffects(id, player.audioSessionId) } catch (_: Exception) {}
        }
    }
    private fun releaseEffects(id: String) {
        try { bassEffects.remove(id)?.release() } catch (_: Exception) {}
        try { loudnessEffects.remove(id)?.release() } catch (_: Exception) {}
        try { equalizers.remove(id)?.release() } catch (_: Exception) {}
    }
    private fun stopOne(id: String) {
        activeIds.remove(id)
        releaseEffects(id)
        val mp = players.remove(id)
        try { mp?.stop() } catch (_: Exception) {}
        try { mp?.release() } catch (_: Exception) {}
        updateBubbleVisuals()
    }
    private fun stopAll() { players.keys.toList().forEach { stopOne(it) }; activeIds.clear(); bassEffects.keys.toList().forEach { releaseEffects(it) }; loudnessEffects.keys.toList().forEach { releaseEffects(it) }; updateBubbleVisuals() }

    private fun minimize() {
        val view = panel ?: return
        view.animate().alpha(0f).scaleX(.94f).scaleY(.94f).setDuration(140)
            .withEndAction {
                removePanel()
                if (!SoundStore.keepBubble(this@FloatingService)) {
                    stopAll()
                    stopSelf()
                }
            }.start()
    }
    /** Animate the orb itself; the custom canvas draws layered glow, arcs and sparks. */
    private fun updateBubbleVisuals() {
        val view = bubble ?: return
        val playing = activeIds.isNotEmpty()
        view.setPlaying(playing)
        if (playing) {
            if (bubblePulse == null) {
                bubblePulse = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1500L
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = AccelerateDecelerateInterpolator()
                    addUpdateListener { animator -> view.setPhase(animator.animatedValue as Float) }
                    start()
                }
            }
        } else {
            bubblePulse?.cancel()
            bubblePulse = null
            view.setPhase(0f)
            view.animate().cancel()
            view.scaleX = 1f
            view.scaleY = 1f
            view.rotation = 0f
            view.alpha = 1f
            view.elevation = dp(8).toFloat()
        }
    }

    private fun refreshPanel() {
        if (expanded) {
            removePanel()
            showPanel()
        }
        updateBubbleVisuals()
    }
    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; expanded = false
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setTextColor(Color.BLACK)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(accent()); cornerRadius = dp(9).toFloat()
        }
        setPadding(dp(4), 0, dp(4), 0); setOnClickListener { action() }
    }
    private fun textButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 9f; setTypeface(null, Typeface.BOLD); setTextColor(accent())
        gravity = Gravity.CENTER; setPadding(dp(7), dp(8), dp(7), dp(8)); setOnClickListener { action() }
    }
    private fun dragListener(): View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        return View.OnTouchListener { view, event ->
            val p = bubbleParams ?: return@OnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = event.rawX; ty = event.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - tx).toInt(); val dy = (event.rawY - ty).toInt()
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                    p.x = (sx + dx).coerceIn(0, resources.displayMetrics.widthPixels - dp(56))
                    p.y = (sy + dy).toInt().coerceIn(0, resources.displayMetrics.heightPixels - dp(56))
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) view.performClick(); true }
                else -> false
            }
        }
    }
    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b.setContentTitle("Soundboard ativo").setContentText("Biblioteca e janela flutuante disponíveis")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build()
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, "Soundboard", NotificationManager.IMPORTANCE_LOW))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        onlineSearchToken++
        networkExecutor.shutdownNow()
        removePanel()
        bubblePulse?.cancel(); bubblePulse = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        stopAll()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_PLAY = "com.soundboard.app.PLAY"
        const val ACTION_STOP_ONE = "com.soundboard.app.STOP_ONE"
        const val ACTION_STOP_ALL = "com.soundboard.app.STOP_ALL"
        const val ACTION_REFRESH = "com.soundboard.app.REFRESH"
        const val ACTION_MINIMIZE = "com.soundboard.app.MINIMIZE"
        const val ACTION_CLOSE = "com.soundboard.app.CLOSE"
        const val EXTRA_ID = "sound_id"
        private const val CHANNEL_ID = "soundboard_playback"
        private const val NOTIFICATION_ID = 4101
    }
}
