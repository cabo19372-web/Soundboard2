package com.soundboard.app

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

/** Jamendo catalog client. Results are restricted to title/artist/album matches,
 * so a genre/tag coincidence cannot masquerade as the requested singer or song. */
data class JamendoTrack(
    val id: String,
    val name: String,
    val artist: String,
    val album: String,
    val image: String,
    val audio: String,
    val downloadAllowed: Boolean
)

object JamendoMusic {
    private const val CLIENT_ID = "2ccd827a"
    private const val BASE = "https://api.jamendo.com/v3.0/tracks/"

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun normalized(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "")
        .replace("[^a-z0-9]+".toRegex(), " ")
        .trim()

    private fun request(term: String, field: String): List<JamendoTrack> {
        val address = "$BASE?client_id=$CLIENT_ID&format=json&limit=50&type=single+albumtrack&audioformat=mp32&order=relevance&$field=${enc(term)}"
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: return emptyList()
            if (code !in 200..299) return emptyList()
            val root = JSONObject(body)
            if (root.optJSONObject("headers")?.optString("status") != "success") return emptyList()
            val rows = root.optJSONArray("results") ?: return emptyList()
            buildList {
                for (i in 0 until rows.length()) {
                    val item = rows.optJSONObject(i) ?: continue
                    val audio = item.optString("audio")
                    if (audio.isBlank() || audio == "null") continue
                    add(JamendoTrack(
                        id = item.optString("id"),
                        name = item.optString("name", "Faixa sem título"),
                        artist = item.optString("artist_name", "Artista desconhecido"),
                        album = item.optString("album_name", ""),
                        image = item.optString("image", ""),
                        audio = audio,
                        downloadAllowed = item.optBoolean("audiodownload_allowed", false)
                    ))
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    fun search(term: String): List<JamendoTrack> {
        val query = term.trim()
        if (query.length < 2) return emptyList()

        // Search the two meaningful fields separately, then use Jamendo's free-text
        // endpoint as a third source. The latter also matches tags, so it is filtered below.
        val gathered = LinkedHashMap<String, JamendoTrack>()
        listOf("namesearch", "artist_name", "search").forEach { field ->
            val tracks = try { request(query, field) } catch (_: Exception) { emptyList() }
            tracks.forEach { track -> gathered.putIfAbsent(track.id, track) }
        }

        val q = normalized(query)
        val tokens = q.split(' ').filter { it.isNotBlank() }
        fun fields(track: JamendoTrack) = listOf(track.name, track.artist, track.album).map(::normalized)
        fun score(track: JamendoTrack): Int {
            val values = fields(track)
            val combined = values.joinToString(" ")
            // Require every query word to occur in a title, artist or album name.
            if (tokens.isEmpty() || !tokens.all { token -> values.any { it.contains(token) } }) return -1
            return when {
                values.any { it == q } -> 100
                normalized(track.artist).contains(q) -> 90
                normalized(track.name).contains(q) -> 85
                normalized(track.album).contains(q) -> 75
                else -> 50 + tokens.count { combined.contains(it) }
            }
        }
        return gathered.values.map { it to score(it) }
            .filter { it.second >= 0 }
            .sortedWith(compareByDescending<Pair<JamendoTrack, Int>> { it.second }.thenBy { it.first.name })
            .take(40)
            .map { it.first }
    }

    fun uri(track: JamendoTrack): Uri = Uri.parse(track.audio)
}
