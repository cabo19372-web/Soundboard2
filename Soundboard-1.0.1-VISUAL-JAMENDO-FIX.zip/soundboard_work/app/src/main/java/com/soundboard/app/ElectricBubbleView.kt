package com.soundboard.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Canvas-rendered energy orb: layered glow, moving arcs and orbiting sparks. */
class ElectricBubbleView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var playing = false
    private var phase = 0f
    private val white = Color.WHITE
    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setPlaying(value: Boolean) {
        if (playing != value) {
            playing = value
            invalidate()
        }
    }

    fun setPhase(value: Float) {
        phase = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = dp(19f)
        val pulse = if (playing) (0.5f + 0.5f * sin(phase * Math.PI * 2.0)).toFloat() else 0f

        if (playing) {
            // Soft, multi-stop radial energy instead of a single solid outline.
            paint.style = Paint.Style.FILL
            paint.shader = RadialGradient(cx, cy, radius * (2.05f + pulse * .28f),
                intArrayOf(0x8878DFFF.toInt(), 0x5560AFFF, 0x2260AFFF, Color.TRANSPARENT),
                floatArrayOf(0f, .48f, .76f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * (2.05f + pulse * .28f), paint)
            paint.shader = null

            // Broken orbit rings rotate in opposite directions.
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            for (i in 0..2) {
                val ringRadius = radius * (1.30f + i * .22f)
                paint.strokeWidth = dp(if (i == 0) 1.8f else 1.1f)
                paint.color = when (i) { 0 -> 0xFFB9F4FF.toInt(); 1 -> 0xFF45B7FF.toInt(); else -> 0x9977AFFF.toInt() }
                val start = phase * 360f * (if (i == 1) -0.7f else 1f) + i * 83f
                val rect = RectF(cx - ringRadius, cy - ringRadius, cx + ringRadius, cy + ringRadius)
                canvas.drawArc(rect, start, if (i == 0) 215f else 115f, false, paint)
            }
            // Sparks orbit the orb and vary in size/brightness.
            paint.style = Paint.Style.FILL
            for (i in 0 until 9) {
                val angle = phase * 6.28318f * (if (i % 2 == 0) 1f else -0.65f) + i * 0.698f
                val orbit = radius * (1.43f + (i % 3) * .24f)
                val x = cx + cos(angle) * orbit
                val y = cy + sin(angle) * orbit
                paint.color = if (i % 3 == 0) white else 0xFF70D8FF.toInt()
                canvas.drawCircle(x, y, dp(1.1f + (i % 3) * .45f), paint)
            }
        }

        // Dark glass core with a blue inner gradient.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx - radius * .28f, cy - radius * .34f, radius * 1.55f,
            intArrayOf(if (playing) 0xFF48BFFF.toInt() else 0xFF2582FF.toInt(),
                if (playing) 0xFF0756C9.toInt() else 0xFF0750B5.toInt(), 0xFF06152D.toInt()),
            null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(1.4f)
        paint.color = if (playing) 0xFFB9F4FF.toInt() else 0xFF101820.toInt()
        canvas.drawCircle(cx, cy, radius - dp(1f), paint)
        paint.style = Paint.Style.FILL
        paint.color = white
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        paint.textSize = dp(if (playing) 22f else 23f)
        val symbol = if (playing) "♫" else "S"
        val baseline = cy - (paint.ascent() + paint.descent()) / 2f
        canvas.drawText(symbol, cx, baseline, paint)
    }
}
