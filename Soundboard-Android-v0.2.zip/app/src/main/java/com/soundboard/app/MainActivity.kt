package com.soundboard.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private var selectedSlot = 0
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: Exception) {}
            val name = queryDisplayName(uri) ?: "Áudio ${selectedSlot + 1}"
            val serviceIntent = Intent(this, FloatingService::class.java).apply {
                action = FloatingService.ACTION_SET_AUDIO; data = uri
                putExtra(FloatingService.EXTRA_SLOT, selectedSlot)
                putExtra(FloatingService.EXTRA_NAME, name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startFloatingService(serviceIntent)
            Toast.makeText(this, "Áudio ${selectedSlot + 1} salvo", Toast.LENGTH_SHORT).show()
        }
        if (intent?.action == ACTION_PICK_AUDIO) finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.action == ACTION_PICK_AUDIO) {
            selectedSlot = intent.getIntExtra(EXTRA_SLOT, 0).coerceIn(0, 7)
            openAudioPicker(); return
        }
        buildHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        if (intent.action == ACTION_PICK_AUDIO) {
            selectedSlot = intent.getIntExtra(EXTRA_SLOT, 0).coerceIn(0, 7)
            openAudioPicker()
        }
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36); setBackgroundColor(0xFF080A08.toInt())
        }
        val title = TextView(this).apply {
            text = "SOUNDBOARD"; textSize = 28f; setTextColor(0xFFB6FF00.toInt()); gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Oito atalhos de áudio em uma janela flutuante."
            textSize = 14f; setTextColor(0xFFB8BDB4.toInt()); gravity = Gravity.CENTER
            setPadding(0, 12, 0, 26)
        }
        val activate = Button(this).apply {
            text = "ATIVAR JANELA FLUTUANTE"; setOnClickListener { activateFloatingWindow() }
        }
        val categories = Button(this).apply {
            text = "GERENCIAR CATEGORIAS"; setOnClickListener { addCategoryDialog() }
        }
        val note = TextView(this).apply {
            text = "Versão 0.2  •  Reprodução simultânea de até 8 efeitos\n\nRoblox: o Android normalmente não permite enviar o áudio de outro app diretamente ao microfone."
            textSize = 12f; setTextColor(0xFF858B81.toInt()); gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title); root.addView(subtitle); root.addView(activate); root.addView(categories); root.addView(note)
        setContentView(root)
    }

    private fun addCategoryDialog() {
        val field = EditText(this).apply { hint = "Nome da categoria"; singleLine = true }
        AlertDialog.Builder(this).setTitle("Nova categoria").setView(field)
            .setPositiveButton("ADICIONAR") { _, _ ->
                if (SoundStore.addCategory(this, field.text.toString()))
                    Toast.makeText(this, "Categoria adicionada", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "Nome vazio ou categoria já existente", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("CANCELAR", null).show()
    }

    private fun activateFloatingWindow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Permita a sobreposição e volte ao Soundboard.", Toast.LENGTH_LONG).show(); return
        }
        startFloatingService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Janela flutuante ativada", Toast.LENGTH_SHORT).show()
    }
    private fun openAudioPicker() { pickAudio.launch(arrayOf("audio/*")) }
    private fun startFloatingService(i: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }
    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }
    companion object {
        const val ACTION_PICK_AUDIO = "com.soundboard.app.PICK_AUDIO"
        const val EXTRA_SLOT = "picker_slot"
    }
}
