package com.soundboard.app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.FrameLayout
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private var query = ""
    private var favoritesOnly = false
    private var categoryFilter = "Todas"
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var libraryTitle: LinearLayout
    private val lime: Int = 0xFF0865FF.toInt()
    private val bg = 0xFF050608.toInt()
    private val card = 0xFF11151D.toInt()
    private val muted = 0xFF9299A6.toInt()
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        var processed = 0
        var unchanged = 0
        uris?.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            var savedUri = uri
            if (SoundStore.denoiseEnabled(this)) {
                try {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null) {
                        val result = WavNoiseReducer.process(bytes, SoundStore.denoiseStrength(this))
                        if (result.bytes != null) {
                            val folder = java.io.File(filesDir, "clean_audio").apply { mkdirs() }
                            val file = java.io.File(folder, "clean_${System.currentTimeMillis()}_${processed}.wav")
                            file.writeBytes(result.bytes)
                            savedUri = Uri.fromFile(file)
                            processed++
                        } else unchanged++
                    } else unchanged++
                } catch (_: Exception) { unchanged++ }
            }
            SoundStore.add(this, savedUri, displayName(uri) ?: "Áudio importado")
        }
        if (!uris.isNullOrEmpty()) {
            refreshLibrary()
            val suffix = if (SoundStore.denoiseEnabled(this)) " • $processed WAV tratado(s), $unchanged mantido(s)" else ""
            Toast.makeText(this, "${uris.size} arquivo(s) importado(s)$suffix", Toast.LENGTH_LONG).show()
            refreshFloating()
        }
    }

    private var lastSoundId: String? = null
    private var lastSoundName: String = "Nenhum áudio selecionado"
    private var activeTab: String = "Início"
    private var categoryRow: LinearLayout? = null
    private var playerName: TextView? = null
    private var playerState: TextView? = null
    private var bottomNav: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        // Android 15 / targetSdk 35: draw edge-to-edge and reserve real system-bar insets.
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        buildHome()
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) refreshLibrary() }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            clipToPadding = false
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Brand header
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(14)) }
        val wolf = ImageView(this).apply {
            setImageResource(R.drawable.wolf_mascot)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(0xFF11151D.toInt(), dp(12))
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        top.addView(wolf, LinearLayout.LayoutParams(dp(62), dp(62)))
        val brandStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        brandStack.addView(label("SOUNDBOARD", 20f, 0xFFF4F4F5.toInt()).apply { setTypeface(null, 1); letterSpacing = .08f })
        brandStack.addView(label("0.8  —  BLUE EDITION", 9f, 0xFF6E9EFF.toInt()).apply { setPadding(0, dp(2), 0, 0); letterSpacing = .12f })
        top.addView(brandStack, LinearLayout.LayoutParams(0, -2, 1f))
        val importIcon = textAction("＋") { pickAudio.launch(arrayOf("audio/*")) }.apply { textSize = 22f; background = rounded(card, dp(12)) }
        top.addView(importIcon, LinearLayout.LayoutParams(dp(42), dp(44)).apply { rightMargin = dp(7) })
        val settingsIcon = textAction("⚙") { showSettings() }.apply { textSize = 20f; background = rounded(card, dp(12)) }
        top.addView(settingsIcon, LinearLayout.LayoutParams(dp(44), dp(44)))
        content.addView(top)

        // Category cards
        content.addView(label("CATEGORIAS", 11f, 0xFFF4F4F5.toInt()).apply { setTypeface(null, 1); setPadding(0, dp(19), 0, dp(9)); letterSpacing = .08f })
        val categoryScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false }
        categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categoryScroll.addView(categoryRow)
        content.addView(categoryScroll, LinearLayout.LayoutParams(-1, dp(48)))
        buildCategoryChips()

        // Search + filter
        val searchLine = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(16), 0, dp(8)) }
        search = EditText(this).apply {
            hint = "Pesquisar sons, categorias ou tags"; setSingleLine(true); textSize = 12f
            setTextColor(0xFFF4F4F5.toInt()); setHintTextColor(muted)
            setPadding(dp(13), 0, dp(10), 0); background = rounded(card, dp(12))
            compoundDrawablePadding = dp(7)
        }
        searchLine.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f))
        val filter = textAction("☷") { chooseCategory() }.apply { textSize = 19f; background = rounded(card, dp(12)) }
        searchLine.addView(filter, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        content.addView(searchLine)
        search.addTextChangedListener(SimpleWatcher { query = it; refreshLibrary() })

        libraryTitle = sectionTitle("BIBLIOTECA", "Seus sons prontos para reproduzir")
        content.addView(libraryTitle)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        // Compact fixed player, above the system navigation area.
        val player = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(10), dp(8))
            background = rounded(0xFF111722.toInt(), dp(14))
        }
        val cover = TextView(this).apply {
            text = "♫"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(0xFF8DB5FF.toInt())
            background = rounded(0xFF1A2B49.toInt(), dp(9))
        }
        player.addView(cover, LinearLayout.LayoutParams(dp(42), dp(42)))
        val playerText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), 0, dp(5), 0) }
        playerName = label(lastSoundName, 11f, 0xFFF4F4F5.toInt()).apply { maxLines = 1 }
        playerState = label("REPRODUTOR • PRONTO", 8f, 0xFF78A5F7.toInt()).apply { setPadding(0, dp(3), 0, 0); letterSpacing = .06f }
        playerText.addView(playerName); playerText.addView(playerState)
        player.addView(playerText, LinearLayout.LayoutParams(0, -2, 1f))
        player.addView(textAction("Ⅱ") { lastSoundId?.let { sendService(FloatingService.ACTION_PLAY, it); playerState?.text = "REPRODUÇÃO / PAUSA" } }, LinearLayout.LayoutParams(dp(38), dp(42)))
        player.addView(textAction("■") { lastSoundId?.let { sendService(FloatingService.ACTION_STOP_ONE, it) }; playerState?.text = "ÁUDIO PARADO" }, LinearLayout.LayoutParams(dp(34), dp(42)))
        root.addView(player, LinearLayout.LayoutParams(-1, dp(60)).apply { leftMargin = dp(12); rightMargin = dp(12); topMargin = dp(5); bottomMargin = dp(7) })

        // Four functional destinations. Lists/favorites, history and about remain inside this activity.
        bottomNav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = rounded(0xFF0B0E14.toInt(), dp(14))
        }
        root.addView(bottomNav, LinearLayout.LayoutParams(-1, dp(58)).apply { leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(4) })
        val screen = FrameLayout(this).apply {
            setBackgroundColor(bg)
            clipChildren = false
            clipToPadding = false
            addView(root, FrameLayout.LayoutParams(-1, -1))
        }
        setContentView(screen)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        androidx.core.view.ViewCompat.requestApplyInsets(root)
        renderBottomNav()
        refreshLibrary()
        // Lightweight staggered entrance; no blur, particles or expensive custom drawing.
        listOf(top, categoryScroll, searchLine, libraryTitle, list, player, bottomNav).forEachIndexed { index, view ->
            view.alpha = 0f; view.translationY = dp(9).toFloat()
            view.animate().alpha(1f).translationY(0f).setStartDelay((index * 45L).coerceAtMost(250L)).setDuration(240).start()
        }
        wolf.alpha = 0f; wolf.scaleX = .72f; wolf.scaleY = .72f
        wolf.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(80).setDuration(420).start()
        brandStack.alpha = 0f; brandStack.translationX = dp(14).toFloat()
        brandStack.animate().alpha(1f).translationX(0f).setStartDelay(260).setDuration(320).start()
        showIntroAnimation(screen)
    }

    /** Reproduces the supplied Soundboard intro clip once, then reveals the home screen. */
    private fun showIntroAnimation(screen: FrameLayout) {
        val overlay = FrameLayout(this).apply { setBackgroundColor(0xFF050608.toInt()) }
        val video = android.widget.VideoView(this).apply {
            setBackgroundColor(0xFF050608.toInt())
        }
        val size = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt().coerceAtMost(390)
        overlay.addView(video, FrameLayout.LayoutParams(dp(size), dp(size), Gravity.CENTER))
        screen.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        var dismissed = false
        fun dismiss() {
            if (dismissed) return
            dismissed = true
            video.stopPlayback()
            overlay.animate().alpha(0f).setDuration(260).withEndAction { screen.removeView(overlay) }.start()
        }
        video.setOnClickListener { dismiss() }
        video.setOnPreparedListener { player ->
            player.setVolume(0f, 0f)
            player.isLooping = false
            video.start()
        }
        video.setOnCompletionListener { dismiss() }
        video.setOnErrorListener { _, _, _ -> dismiss(); true }
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.soundboard_intro}"))
    }

    private fun buildCategoryChips() {
        val row = categoryRow ?: return
        row.removeAllViews()
        val cats = listOf("Todos", "Memes", "Jogos", "Músicas", "Favoritos")
        cats.forEach { cat ->
            val selected = (cat == "Todos" && categoryFilter == "Todas" && !favoritesOnly) ||
                (cat == "Favoritos" && favoritesOnly) || (cat != "Todos" && cat != "Favoritos" && categoryFilter.equals(cat, true))
            val chip = TextView(this).apply {
                text = cat; textSize = 11f; gravity = Gravity.CENTER
                setTextColor(if (selected) 0xFFF4F4F5.toInt() else muted)
                setPadding(dp(16), 0, dp(16), 0)
                background = rounded(if (selected) 0xFF12336A.toInt() else card, dp(12))
                setOnClickListener {
                    favoritesOnly = cat == "Favoritos"
                    categoryFilter = when (cat) { "Todos", "Favoritos" -> "Todas"; "Músicas" -> "Música"; else -> cat }
                    buildCategoryChips(); refreshLibrary()
                }
            }
            row.addView(chip, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(7) })
        }
    }

    private fun renderBottomNav() {
        val nav = bottomNav ?: return
        nav.removeAllViews()
        listOf("Início" to "⌂", "Minhas Listas" to "▤", "Histórico" to "◷", "Sobre" to "ⓘ").forEach { (name, icon) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setOnClickListener {
                    activeTab = name
                    when (name) {
                        "Início" -> { favoritesOnly = false; categoryFilter = "Todas"; query = ""; if (::search.isInitialized) search.setText("") }
                        "Minhas Listas" -> { favoritesOnly = true; categoryFilter = "Todas" }
                        "Histórico" -> showHistory()
                        "Sobre" -> showAbout()
                    }
                    buildCategoryChips(); renderBottomNav(); refreshLibrary()
                }
            }
            item.addView(label(icon, 17f, if (activeTab == name) 0xFF5D98FF.toInt() else muted).apply { gravity = Gravity.CENTER })
            item.addView(label(name, 8f, if (activeTab == name) 0xFF8DB5FF.toInt() else muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) })
            nav.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun showHistory() {
        val history = getSharedPreferences("soundboard_history", MODE_PRIVATE).getString("items", "").orEmpty()
        val names = history.split("|").filter { it.isNotBlank() }.distinct()
        AlertDialog.Builder(this).setTitle("Histórico recente")
            .setItems(if (names.isEmpty()) arrayOf("Nenhuma reprodução registrada") else names.toTypedArray()) { _, i ->
                if (names.isNotEmpty()) SoundStore.all(this).firstOrNull { it.name == names[i] }?.let { playSound(it) }
            }.setPositiveButton("FECHAR", null).show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this).setTitle("SOUNDBOARD • BLUE EDITION")
            .setMessage("Versão 0.8\nPackage: com.soundboard.app\n\nSua central de áudio para efeitos, memes, jogos e sons favoritos.")
            .setPositiveButton("OK", null).show()
    }

    private fun playSound(sound: SoundStore.Sound) {
        lastSoundId = sound.id; lastSoundName = sound.name
        playerName?.text = sound.name; playerState?.text = "ENVIADO PARA REPRODUÇÃO"
        sendService(FloatingService.ACTION_PLAY, sound.id)
        refreshLibrary()
        val prefs = getSharedPreferences("soundboard_history", MODE_PRIVATE)
        val old = prefs.getString("items", "").orEmpty().split("|").filter { it.isNotBlank() }
        prefs.edit().putString("items", (listOf(sound.name) + old).distinct().take(30).joinToString("|")).apply()
    }

    private fun refreshLibrary() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val all = SoundStore.all(this)
        val filtered = all.filter {
            (!favoritesOnly || it.favorite) &&
            (categoryFilter == "Todas" || it.category.equals(categoryFilter, true)) &&
            (it.name.contains(query, true) || it.category.contains(query, true))
        }
        if (::libraryTitle.isInitialized) libraryTitle.getChildAt(0)?.let { (it as? TextView)?.text = "BIBLIOTECA  •  ${filtered.size}" }
        if (filtered.isEmpty()) {
            list.addView(label(if (all.isEmpty()) "Sua biblioteca está vazia.\nImporte arquivos de áudio para começar." else "Nenhum áudio encontrado.", 13f, muted).apply {
                gravity = Gravity.CENTER; setPadding(dp(20), dp(34), dp(20), dp(34))
            })
        }
        val columns = SoundStore.gridColumns(this).coerceIn(2, 4)
        val chunks = filtered.chunked(columns)
        chunks.forEach { group ->
            val gridRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { sound ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(9), dp(8), dp(7), dp(8))
                    background = rounded(if (sound.id == lastSoundId) 0xFF172947.toInt() else card, dp(14))
                    isClickable = true; isFocusable = true
                    setOnClickListener { playSound(sound) }
                    setOnLongClickListener { soundMenu(sound); true }
                }
                val art = TextView(this).apply {
                    text = "♫"; textSize = 21f; gravity = Gravity.CENTER
                    setTextColor(0xFF8DB5FF.toInt())
                    background = rounded(0xFF172947.toInt(), dp(10))
                }
                tile.addView(art, LinearLayout.LayoutParams(dp(38), dp(42)))
                val textStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(3), 0) }
                textStack.addView(label(sound.name, 11f, 0xFFF4F4F5.toInt()).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
                textStack.addView(label(sound.category.uppercase(), 7f, muted).apply { setPadding(0, dp(2), 0, 0); maxLines = 1 })
                tile.addView(textStack, LinearLayout.LayoutParams(0, -2, 1f))
                tile.addView(textAction(if (sound.favorite) "★" else "☆") {
                    SoundStore.update(this@MainActivity, sound.copy(favorite = !sound.favorite)); refreshLibrary()
                }.apply { textSize = 15f; setTextColor(if (sound.favorite) 0xFF5D98FF.toInt() else muted) }, LinearLayout.LayoutParams(dp(25), dp(38)))
                tile.addView(textAction("▶") { playSound(sound) }.apply {
                    textSize = 13f; setTextColor(0xFFF4F4F5.toInt())
                    background = rounded(0xFF202938.toInt(), dp(20))
                }, LinearLayout.LayoutParams(dp(32), dp(32)))
                tile.alpha = 0f; tile.translationY = dp(6).toFloat()
                tile.animate().alpha(1f).translationY(0f).setStartDelay(group.indexOf(sound) * 35L).setDuration(200).start()
                val lp = LinearLayout.LayoutParams(0, dp(68), 1f).apply { rightMargin = dp(6); bottomMargin = dp(8) }
                gridRow.addView(tile, lp)
            }
            repeat((columns - group.size).coerceAtLeast(0)) {
                gridRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            list.addView(gridRow)
        }
    }

    private fun sectionTitle(title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(0, dp(13), 0, dp(8))
        addView(label(title, 12f, 0xFFF4F4F5.toInt()).apply { setTypeface(null, 1); letterSpacing = .07f })
        addView(label(subtitle, 9f, muted).apply { setPadding(0, dp(2), 0, 0) })
    }

    private fun soundMenu(s: SoundStore.Sound) {
        val options = arrayOf("Reproduzir", "Renomear", "Alterar categoria", if (s.favorite) "Remover favorito" else "Adicionar favorito", "Excluir")
        AlertDialog.Builder(this).setTitle(s.name).setItems(options) { _, which ->
            when (which) {
                0 -> playSound(s)
                1 -> rename(s)
                2 -> changeCategory(s)
                3 -> { SoundStore.update(this, s.copy(favorite = !s.favorite)); buildCategoryChips(); refreshLibrary() }
                4 -> confirmDelete(s)
            }
        }.show()
    }
    private fun rename(s: SoundStore.Sound) {
        val field = EditText(this).apply { setText(s.name); setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Renomear áudio").setView(field)
            .setPositiveButton("SALVAR") { _, _ ->
                val name = field.text.toString().trim()
                if (name.isNotEmpty()) { SoundStore.update(this, s.copy(name = name)); refreshLibrary(); refreshFloating() }
            }.setNegativeButton("CANCELAR", null).show()
    }
    private fun changeCategory(s: SoundStore.Sound) {
        val cats = (SoundStore.categories(this) + "Nova categoria").distinct()
        AlertDialog.Builder(this).setTitle("Categoria").setItems(cats.toTypedArray()) { _, i ->
            if (cats[i] == "Nova categoria") {
                val field = EditText(this).apply { hint = "Nome da categoria" }
                AlertDialog.Builder(this).setTitle("Nova categoria").setView(field)
                    .setPositiveButton("SALVAR") { _, _ ->
                        val name = field.text.toString().trim()
                        if (name.isNotEmpty()) { SoundStore.update(this, s.copy(category = name)); refreshLibrary(); refreshFloating() }
                    }.setNegativeButton("CANCELAR", null).show()
            } else { SoundStore.update(this, s.copy(category = cats[i])); refreshLibrary(); refreshFloating() }
        }.show()
    }
    private fun chooseCategory() {
        val cats = arrayOf("Todas") + SoundStore.categories(this).distinct().toTypedArray()
        AlertDialog.Builder(this).setTitle("Filtrar categoria").setItems(cats) { _, i ->
            categoryFilter = cats[i]; favoritesOnly = false; buildCategoryChips(); refreshLibrary()
        }.show()
    }
    private fun confirmDelete(s: SoundStore.Sound) {
        AlertDialog.Builder(this).setTitle("Excluir áudio?")
            .setMessage("“${s.name}” será removido da biblioteca.")
            .setPositiveButton("EXCLUIR") { _, _ ->
                sendService(FloatingService.ACTION_STOP_ONE, s.id)
                SoundStore.delete(this, s.id); refreshLibrary(); refreshFloating()
            }.setNegativeButton("CANCELAR", null).show()
    }
    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(label("VOLUME PADRÃO", 13f, -1))
        box.addView(label("Volume de saída do Soundboard", 10f, muted))
        val volume = SeekBar(this).apply { max = 100; progress = SoundStore.volume(this@MainActivity) }
        box.addView(volume)
        box.addView(label("GRAVES", 13f, lime).apply { setPadding(0, dp(10), 0, 0) })
        box.addView(label("Bass Boost do Android, quando disponível", 10f, muted))
        val bass = SeekBar(this).apply { max = 100; progress = SoundStore.bass(this@MainActivity) / 10 }
        box.addView(bass)
        box.addView(label("AMPLIFICAÇÃO DIGITAL", 13f, lime).apply { setPadding(0, dp(10), 0, 0) })
        box.addView(label("Pode aumentar distorção; use com moderação", 10f, muted))
        val boost = SeekBar(this).apply { max = 600; progress = SoundStore.boost(this@MainActivity) }
        box.addView(boost)
        box.addView(label("EQUALIZADOR DE 5 BANDAS", 13f, lime).apply { setPadding(0, dp(12), 0, 0) })
        box.addView(label("Ajuste de -12 dB a +12 dB. Depende do suporte do aparelho.", 10f, muted))
        val eqNames = listOf("60 Hz • SUBGRAVE", "230 Hz • GRAVE", "910 Hz • MÉDIO", "3,6 kHz • PRESENÇA", "14 kHz • AGUDO")
        (0..4).forEach { band ->
            val bandLabel = label("${eqNames[band]}  ${SoundStore.eqBand(this, band)} dB", 10f, -1)
            box.addView(bandLabel)
            val bandSeek = SeekBar(this).apply {
                max = 24; progress = SoundStore.eqBand(this@MainActivity, band) + 12
            }
            bandSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seek: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val value = progress - 12
                        SoundStore.setEqBand(this@MainActivity, band, value)
                        bandLabel.text = "${eqNames[band]}  $value dB"
                        refreshFloating()
                    }
                }
                override fun onStartTrackingTouch(seek: SeekBar?) {}
                override fun onStopTrackingTouch(seek: SeekBar?) {}
            })
            box.addView(bandSeek)
        }
        val safe = CheckBox(this).apply {
            text = "Limitar volume de saída a 85%"; setTextColor(-1)
            isChecked = SoundStore.safeLimit(this@MainActivity)
        }
        box.addView(safe)
        box.addView(label("Este limite reduz o nível máximo de saída; não é um limiter de pico em tempo real.", 9f, muted))
        box.addView(label("REDUÇÃO DE RUÍDO NA IMPORTAÇÃO", 12f, lime).apply { setPadding(0, dp(10), 0, 0) })
        val denoise = CheckBox(this).apply {
            text = "Tratar WAV PCM 16-bit ao importar"; setTextColor(-1)
            isChecked = SoundStore.denoiseEnabled(this@MainActivity)
        }
        box.addView(denoise)
        box.addView(label("Redutor suave tipo noise gate: diminui trechos muito baixos entre falas/sons. Não remove ruído contínuo como um denoiser de IA.", 9f, muted))
        val strengthLabel = label("INTENSIDADE  •  ${SoundStore.denoiseStrength(this)}%", 10f, -1)
        box.addView(strengthLabel)
        val strength = SeekBar(this).apply { max = 100; progress = SoundStore.denoiseStrength(this@MainActivity) }
        box.addView(strength)
        strength.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser) strengthLabel.text = "INTENSIDADE  •  $value%"
            }
            override fun onStartTrackingTouch(seek: SeekBar?) {}
            override fun onStopTrackingTouch(seek: SeekBar?) {}
        })
        box.addView(label("Somente novos arquivos WAV compatíveis serão processados. MP3, M4A e outros formatos serão importados sem alteração. O original não é sobrescrito.", 9f, muted))
        box.addView(label("GRADE DA BIBLIOTECA", 13f, lime).apply { setPadding(0, dp(12), 0, 0) })
        box.addView(label("Quantidade de colunas na biblioteca", 10f, muted))
        val columns = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("2 colunas", "3 colunas", "4 colunas"))
            setSelection(SoundStore.gridColumns(this@MainActivity) - 2)
        }
        box.addView(columns)
        box.addView(label("TAMANHO DOS BOTÕES", 13f, lime).apply { setPadding(0, dp(10), 0, 0) })
        val buttonSizeLabel = label("Tamanho  •  ${SoundStore.buttonScale(this)}%", 10f, -1)
        box.addView(buttonSizeLabel)
        val buttonSize = SeekBar(this).apply { max = 50; progress = SoundStore.buttonScale(this@MainActivity) - 75 }
        buttonSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser) buttonSizeLabel.text = "Tamanho  •  ${value + 75}%"
            }
            override fun onStartTrackingTouch(seek: SeekBar?) {}
            override fun onStopTrackingTouch(seek: SeekBar?) {}
        })
        box.addView(buttonSize)
        box.addView(label("Identidade visual Blue Edition: azul elétrico em ações e destaques, com fundos pretos e grafite.", 9f, muted))
        val keep = CheckBox(this).apply {
            text = "Manter bolinha após minimizar"; setTextColor(-1); isChecked = SoundStore.keepBubble(this@MainActivity)
        }
        box.addView(keep)
        val saveSeek = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                if (!user) return
                when (s) {
                    volume -> SoundStore.setVolume(this@MainActivity, p)
                    bass -> SoundStore.setBass(this@MainActivity, p * 10)
                    boost -> SoundStore.setBoost(this@MainActivity, p)
                }
                refreshFloating()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        volume.setOnSeekBarChangeListener(saveSeek); bass.setOnSeekBarChangeListener(saveSeek); boost.setOnSeekBarChangeListener(saveSeek)
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle("AUDIO STUDIO • 0.8").setView(scroll)
            .setPositiveButton("SALVAR") { _, _ ->
                SoundStore.setSafeLimit(this, safe.isChecked)
                SoundStore.setDenoiseEnabled(this, denoise.isChecked)
                SoundStore.setDenoiseStrength(this, strength.progress)
                SoundStore.setAccent(this, "blue")
                SoundStore.setGridColumns(this, columns.selectedItemPosition + 2)
                SoundStore.setButtonScale(this, buttonSize.progress + 75)
                SoundStore.setKeepBubble(this, keep.isChecked)
                refreshLibrary()
                refreshFloating()
            }.setNegativeButton("FECHAR", null).show()
    }

    private fun activateFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Ative Permitir sobreposição e volte ao app.", Toast.LENGTH_LONG).show()
        } else {
            startServiceCompat(Intent(this, FloatingService::class.java))
            Toast.makeText(this, "Janela flutuante ativada", Toast.LENGTH_SHORT).show()
        }
    }
    private fun refreshFloating() = sendService(FloatingService.ACTION_REFRESH)
    private fun sendService(action: String, id: String? = null) {
        val i = Intent(this, FloatingService::class.java).setAction(action)
        if (id != null) i.putExtra(FloatingService.EXTRA_ID, id)
        startServiceCompat(i)
    }
    private fun startServiceCompat(i: Intent) {
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 11f; isAllCaps = false; setTextColor(0xFFF4F4F5.toInt())
        background = rounded(lime, dp(10)); setPadding(dp(8), 0, dp(8), 0); setOnClickListener { action() }
    }
    private fun textAction(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 10f; setTextColor(lime); setTypeface(null, 1)
        gravity = Gravity.CENTER; setPadding(dp(9), dp(8), dp(9), dp(8)); setOnClickListener { action() }
    }
    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}


private class SimpleWatcher(private val changed: (String) -> Unit) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        changed(s?.toString().orEmpty())
    }
    override fun afterTextChanged(s: Editable?) {}
}
