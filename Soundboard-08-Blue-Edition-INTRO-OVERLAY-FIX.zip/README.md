# Soundboard 0.8 — Blue Edition

Projeto Android Kotlin do Soundboard (`com.soundboard.app`).

## Correções desta revisão

- Mantém a animação de entrada MP4 (`soundboard_intro.mp4`) e coloca a superfície de vídeo acima da interface para que ela fique visível durante a reprodução.
- Adiciona acesso direto à janela flutuante pelo ícone na barra superior e também pelas configurações.
- Ao conceder a permissão **Exibir sobre outros apps**, o serviço flutuante é iniciado automaticamente quando o usuário retorna ao Soundboard.
- Mantém o `FloatingService`, biblioteca de sons, mascote, configurações de áudio e demais recursos existentes.

## Compilar

```bash
gradle --no-daemon clean assembleDebug
```

APK Debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Janela flutuante

Toque no ícone de janela na barra superior (ou em **Configurações > ATIVAR JANELA FLUTUANTE**). Na tela de permissões do Android/Samsung, permita **Exibir sobre outros apps** para o Soundboard e volte ao aplicativo. A bolinha flutuante deverá aparecer.

A janela permite controlar a reprodução por cima de outros aplicativos. O Android não fornece ao Soundboard uma forma universal de injetar o áudio diretamente no microfone de aplicativos de chamada; para que outras pessoas na chamada ouçam, isso depende do roteamento de áudio e do microfone do aparelho/headset.
