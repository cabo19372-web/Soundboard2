plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.soundboard.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.soundboard.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 8
        versionName = "0.8"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
}
