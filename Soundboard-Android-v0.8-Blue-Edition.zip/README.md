# Soundboard Android 0.8 — Blue Edition

Projeto Android nativo em Kotlin. Esta versão foi construída sobre o código-fonte 0.7, preservando a biblioteca de áudios, reprodução, janela flutuante, Audio Studio e processamento WAV já existentes.

## Identidade Blue Edition
- Fundo principal preto `#050608`.
- Cartões grafite `#11151D`.
- Azul elétrico `#0865FF` para botões, ícones, seleções e destaques.
- Texto principal `#F4F4F5`.
- Ícone próprio do aplicativo.

## Novidades implementadas na 0.8
- Atualização visual da tela principal, cartões, controles e janela flutuante para a identidade Blue Edition.
- Ícone próprio do aplicativo no Manifest.
- Biblioteca em grade configurável com 2, 3 ou 4 colunas.
- Controle do tamanho vertical dos botões de reprodução (75% a 125%).
- Versão Android atualizada para `versionCode 8` e `versionName 0.8`.
- GitHub Actions publica o artefato `Soundboard-v0.8-debug-apk`.

## Funcionalidades preservadas da 0.7
- Importação de múltiplos arquivos de áudio.
- Biblioteca dinâmica, pesquisa, categorias, renomeação, exclusão e favoritos.
- Janela flutuante com pesquisa, reprodução e ação PARAR TODOS.
- Reprodução simultânea por instâncias independentes de MediaPlayer.
- Volume geral, BassBoost, amplificação digital e equalizador de cinco bandas, conforme suporte do Android.
- Limite simples de volume de saída.
- Redução de ruído tipo noise gate para WAV PCM 16-bit mono/estéreo durante importação.

## Limitações / itens ainda não implementados nesta entrega
A 0.8 não implementa ainda todos os recursos listados como desejados para versões futuras. Permanecem pendentes: fotos/capas por áudio, tags personalizadas, organização manual por arrastar, favoritos em páginas deslizáveis na janela, transparência/encaixe automático/redimensionamento avançado, volume individual por som, fila/sequência/aleatório, normalização, gravação pelo microfone, medidor visual, perfis por jogo, widget Android, atalho nas configurações rápidas, extração de áudio de vídeo, backup completo e detecção de duplicados.

## Compilação pelo GitHub Actions
1. Extraia o conteúdo deste ZIP diretamente na raiz do repositório GitHub (as pastas `app/` e `.github/` devem ficar diretamente na raiz).
2. Faça commit e push na branch `main`.
3. Abra a aba **Actions** e execute **Build Soundboard APK** (ou aguarde o build automático após o push).
4. Baixe o artefato `Soundboard-v0.8-debug-apk`.

## Identificação
- Package: `com.soundboard.app`
- versionCode: `8`
- versionName: `0.8`
- SDK de compilação: 35
- Min SDK: 23

**Nota:** o ZIP foi verificado estruturalmente. A compilação Android e o teste no Samsung Galaxy A06 ainda precisam ser confirmados pelo GitHub Actions e no próprio aparelho.
