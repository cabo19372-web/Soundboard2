# Soundboard Android — versão 0.2

Projeto Android em Kotlin, pacote `com.soundboard.app`, preparado para gerar APK Debug pelo GitHub Actions usando apenas o celular.

## Recursos 0.2
- Bolha flutuante arrastável e painel que expande/minimiza.
- Oito slots independentes: cada botão recebe seu próprio arquivo de áudio.
- Reprodução simultânea dos slots (limitada pelos recursos do aparelho e pelos formatos suportados pelo Android).
- Pausar/continuar o áudio do respectivo slot tocando novamente no botão.
- Categorias personalizadas; adicione-as na tela principal e alterne a categoria de cada slot em `ALTERAR`.
- Botão `PARAR TODOS OS SONS` e volume geral.
- Preferências persistentes: arquivos e categorias continuam associados aos slots após fechar o painel ou reiniciar o app, desde que os arquivos originais permaneçam acessíveis.
- Serviço em primeiro plano para manter a janela e a reprodução durante o uso de outros apps.
- Interface preta com verde-limão `#B6FF00`.

## Limitação importante: Roblox Voice Chat
Esta versão **não injeta** o som do Soundboard no microfone do Roblox. Em Android comum, um app não pode redirecionar livremente a saída de áudio de outro app para a entrada de microfone. A captura de reprodução do Android (quando permitida) é voltada a captura autorizada de áudio e não equivale a um dispositivo de microfone virtual. O app não solicita acesso ao microfone nem afirma transmitir os efeitos aos outros jogadores.

No Galaxy A06, a compatibilidade também depende da versão do Android/One UI, das políticas do Roblox e do roteamento de áudio do sistema. O que esta versão faz é reproduzir os efeitos pela saída de áudio selecionada no telefone. Um teste real de chamada/voice chat ainda é necessário para avaliar qualquer comportamento externo; não há garantia de que outras pessoas ouvirão os sons.

## Compilar pelo celular (GitHub Actions)
1. Extraia o ZIP no celular.
2. No GitHub, crie ou abra o repositório `Soundboard`.
3. Envie **o conteúdo** desta pasta para a raiz do repositório, mantendo `.github/workflows/build-apk.yml` e as pastas `app/` e `gradle`/arquivos Gradle.
4. Abra a aba **Actions** e selecione **Build Soundboard APK**.
5. Toque em **Run workflow** (ou faça push na branch `main`).
6. Aguarde o job terminar com sucesso. Abra a execução e baixe o artefato **Soundboard-v0.2-debug-apk**.
7. Extraia o ZIP baixado e instale `app-debug.apk`. Se o Android pedir, permita a instalação pelo navegador/gerenciador de arquivos usado.

## Primeiro uso
1. Abra o Soundboard e toque em `ATIVAR JANELA FLUTUANTE`.
2. Conceda `Permitir sobreposição a outros apps`.
3. Toque na bolha verde para abrir o painel.
4. Em cada slot, toque `CARREGAR` e escolha um arquivo de áudio.
5. Toque no botão numerado para iniciar/pausar aquele efeito. Use `ALTERAR` para alternar a categoria e `PARAR TODOS OS SONS` para interromper todos.
6. Para criar categorias, volte à tela principal e toque em `GERENCIAR CATEGORIAS`.

## Notas técnicas
- `minSdk 23`, `targetSdk 35`, Java 17, Kotlin 2.0.21 e Android Gradle Plugin 8.6.1.
- O workflow usa Gradle 8.7 e publica um APK Debug como artefato.
- A compilação e o funcionamento em um Galaxy A06 não foram executados/testados nesta entrega. O resultado real deve ser confirmado no GitHub Actions e no aparelho.
- A reprodução simultânea consome mais memória/CPU que um único player; arquivos muito longos ou formatos incomuns podem falhar dependendo do decoder Android.
