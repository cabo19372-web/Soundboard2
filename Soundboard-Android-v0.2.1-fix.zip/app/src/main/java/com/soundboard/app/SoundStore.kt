package com.soundboard.app

import android.content.Context
import android.net.Uri

/** Small persistent store for the eight independent sound slots. */
object SoundStore {
    private const val PREFS = "soundboard_v02"
    private const val CATEGORIES = "categories"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    data class Slot(val uri: String?, val name: String, val category: String)

    fun getSlot(context: Context, index: Int): Slot {
        val p = prefs(context)
        return Slot(p.getString("slot_${index}_uri", null),
            p.getString("slot_${index}_name", "Sem áudio") ?: "Sem áudio",
            p.getString("slot_${index}_category", "Geral") ?: "Geral")
    }

    fun setSlot(context: Context, index: Int, uri: Uri, name: String) {
        prefs(context).edit().putString("slot_${index}_uri", uri.toString())
            .putString("slot_${index}_name", name).apply()
    }

    fun setCategory(context: Context, index: Int, category: String) {
        prefs(context).edit().putString("slot_${index}_category", category).apply()
    }

    fun categories(context: Context): List<String> =
        (listOf("Geral") + (prefs(context).getString(CATEGORIES, "") ?: "")
            .split("\n").map { it.trim() }.filter { it.isNotEmpty() })
            .distinct().take(30)

    fun addCategory(context: Context, category: String): Boolean {
        val clean = category.trim().take(24)
        if (clean.isBlank() || categories(context).any { it.equals(clean, true) }) return false
        val custom = categories(context).filter { it != "Geral" } + clean
        prefs(context).edit().putString(CATEGORIES, custom.joinToString("\n")).apply()
        return true
    }
}
