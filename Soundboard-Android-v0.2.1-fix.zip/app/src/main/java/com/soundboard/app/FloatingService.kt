package com.soundboard.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var expanded = false
    private val players = arrayOfNulls<MediaPlayer>(8)
    private var volume = 75

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (android.provider.Settings.canDrawOverlays(this)) createBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SET_AUDIO) {
            val slot = intent.getIntExtra(EXTRA_SLOT, 0).coerceIn(0, 7)
            intent.data?.let { uri ->
                val name = intent.getStringExtra(EXTRA_NAME) ?: "Áudio ${slot + 1}"
                SoundStore.setSlot(this, slot, uri, name)
                stopSlot(slot)
                refreshPanel()
                Toast.makeText(this, "Áudio ${slot + 1} importado", Toast.LENGTH_SHORT).show()
            }
        }
        return START_STICKY
    }

    private fun createBubble() {
        if (bubble != null) return
        bubbleParams = WindowManager.LayoutParams(dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(180)
        }
        bubble = TextView(this).apply {
            text = "S"; textSize = 24f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.BLACK); gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(LIME); setStroke(dp(2), Color.BLACK)
            }
            elevation = dp(8).toFloat()
            setOnClickListener { if (expanded) removePanel() else showPanel() }
            setOnTouchListener(dragListener())
        }
        wm.addView(bubble, bubbleParams)
    }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 12, 10)); cornerRadius = dp(16).toFloat()
                setStroke(dp(1), LIME)
            }
            elevation = dp(14).toFloat()
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "SOUNDBOARD  /  0.2"; textSize = 15f; setTypeface(null, Typeface.BOLD)
            setTextColor(LIME)
        }
        val close = textButton("FECHAR") { removePanel() }
        header.addView(title, LinearLayout.LayoutParams(0, dp(40), 1f)); header.addView(close)
        root.addView(header)

        val scroll = ScrollView(this)
        val slots = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (i in 0 until 8) slots.addView(makeSlotRow(i))
        scroll.addView(slots)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(330)))

        val stopAll = actionButton("PARAR TODOS OS SONS") { stopAll() }
        root.addView(stopAll, LinearLayout.LayoutParams(-1, dp(43)))
        val volumeTitle = TextView(this).apply {
            text = "VOLUME GERAL"; textSize = 10f; setTextColor(LIME)
            setPadding(0, dp(7), 0, 0)
        }
        root.addView(volumeTitle)
        root.addView(SeekBar(this).apply {
            max = 100; progress = volume
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    volume = p; players.forEach { it?.setVolume(p / 100f, p / 100f) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        val note = TextView(this).apply {
            text = "Os sons são reproduzidos na saída de áudio do aparelho."
            textSize = 10f; setTextColor(0xFF9BA095.toInt()); setPadding(0, dp(4), 0, 0)
        }
        root.addView(note)
        val p = WindowManager.LayoutParams(dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (bubbleParams?.x ?: dp(12)).coerceAtMost(resources.displayMetrics.widthPixels - dp(310))
            y = ((bubbleParams?.y ?: dp(180)) + dp(62)).coerceAtMost(resources.displayMetrics.heightPixels - dp(430))
        }
        panel = root; wm.addView(root, p); expanded = true
    }

    private fun makeSlotRow(index: Int): LinearLayout {
        val data = SoundStore.getSlot(this, index)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, dp(5))
        }
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val play = actionButton("${index + 1}  ▶") { playSlot(index) }
        line.addView(play, LinearLayout.LayoutParams(dp(72), dp(42)))
        val name = TextView(this).apply {
            text = data.name; textSize = 11f; setTextColor(Color.WHITE); maxLines = 2
            setPadding(dp(7), 0, dp(4), 0)
        }
        line.addView(name, LinearLayout.LayoutParams(0, dp(42), 1f))
        line.addView(textButton("CARREGAR") { requestImport(index) })
        row.addView(line)
        val categoryLine = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val cat = TextView(this).apply {
            text = "CATEGORIA: ${data.category}"; textSize = 10f; setTextColor(LIME)
            setPadding(dp(78), 0, 0, 0)
        }
        categoryLine.addView(cat, LinearLayout.LayoutParams(0, dp(25), 1f))
        categoryLine.addView(textButton("ALTERAR") { cycleCategory(index) })
        row.addView(categoryLine)
        val divider = View(this).apply { setBackgroundColor(0xFF30362B.toInt()) }
        row.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        return row
    }

    private fun requestImport(slot: Int) {
        val i = Intent(this, MainActivity::class.java).apply {
            action = MainActivity.ACTION_PICK_AUDIO
            putExtra(MainActivity.EXTRA_SLOT, slot)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(i)
    }

    private fun cycleCategory(slot: Int) {
        val categories = SoundStore.categories(this)
        val current = SoundStore.getSlot(this, slot).category
        val next = categories[(categories.indexOf(current).coerceAtLeast(0) + 1) % categories.size]
        SoundStore.setCategory(this, slot, next); refreshPanel()
    }

    private fun refreshPanel() { if (expanded) { removePanel(); showPanel() } }

    private fun playSlot(slot: Int) {
        val existing = players[slot]
        if (existing != null) {
            try {
                if (existing.isPlaying) { existing.pause(); return }
                existing.start(); return
            } catch (_: Exception) { stopSlot(slot) }
        }
        val data = SoundStore.getSlot(this, slot)
        val uri = data.uri?.let { Uri.parse(it) }
        if (uri == null) { Toast.makeText(this, "Carregue um áudio no botão ${slot + 1}.", Toast.LENGTH_SHORT).show(); return }
        try {
            val mp = MediaPlayer()
            players[slot] = mp
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            mp.setDataSource(this, uri)
            mp.setVolume(volume / 100f, volume / 100f)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { stopSlot(slot) }
            mp.setOnErrorListener { _, _, _ -> stopSlot(slot); true }
            mp.prepareAsync()
        } catch (_: Exception) {
            stopSlot(slot); Toast.makeText(this, "Falha ao abrir o áudio ${slot + 1}.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopSlot(slot: Int) {
        val mp = players[slot]; players[slot] = null
        try { mp?.stop() } catch (_: Exception) {}
        try { mp?.release() } catch (_: Exception) {}
    }
    private fun stopAll() { for (i in 0..7) stopSlot(i) }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; expanded = false
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setTextColor(Color.BLACK)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(LIME); cornerRadius = dp(8).toFloat()
        }
        setPadding(dp(5), 0, dp(5), 0); setOnClickListener { action() }
    }
    private fun textButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 9f; setTypeface(null, Typeface.BOLD); setTextColor(LIME)
        gravity = Gravity.CENTER; setPadding(dp(7), dp(8), dp(7), dp(8)); setOnClickListener { action() }
    }

    private fun dragListener(): View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        return View.OnTouchListener { view, event ->
            val p = bubbleParams ?: return@OnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = event.rawX; ty = event.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - tx).toInt(); val dy = (event.rawY - ty).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    p.x = (sx + dx).coerceIn(0, resources.displayMetrics.widthPixels - dp(56))
                    p.y = (sy + dy).coerceIn(0, resources.displayMetrics.heightPixels - dp(56))
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}; true
                }
                MotionEvent.ACTION_UP -> { if (!moved) view.performClick(); true }
                else -> false
            }
        }
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Soundboard ativo").setContentText("Janela flutuante e áudio disponíveis")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build()
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, "Soundboard", NotificationManager.IMPORTANCE_LOW))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        removePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; stopAll(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_SET_AUDIO = "com.soundboard.app.SET_AUDIO"
        const val EXTRA_SLOT = "slot_index"
        const val EXTRA_NAME = "audio_name"
        private const val CHANNEL_ID = "soundboard_playback"
        private const val NOTIFICATION_ID = 4101
        private const val LIME = 0xFFB6FF00.toInt()
    }
}
